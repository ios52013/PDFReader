//
//  HYRFileMeta.h
//  HYRPDFReader
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/26.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *    @brief    文件处理类型
 */
typedef enum {
    SigningDocument = 0,       /**< 可签发文件 */
    CommonDocument,           /**< 一般文件 */
    VotingDocument              /**< 表决文件 */
}FileType;
/**
 *    @brief    文件下载状态
 */
typedef enum {
    Unload = 0,       /**< 未下载 */
    Loading = 1,           /**< 下载中 */
    DoneLode = 2,              /**< 下载完成 */
    EroerLode = 3         /**< 下载失败 */
}FileDownLoadType;
/**
 *    @brief    文件已读状态
 */
typedef enum {
    Unread = 0,       /**< 未读 */
    readed = 1,           /**< 已读 */
}FileReadType;


@interface HYRFileMeta : NSObject

//文件创建时间
@property(nonatomic,strong)NSString *createtime;
//文件加解密标识符
@property(nonatomic,strong)NSString *materialIdentification;
//文件id
@property(nonatomic,strong)NSString *materialid;
//文件名
@property(nonatomic,strong)NSString *materialname;
//文件大小
@property(nonatomic,assign)NSUInteger materialsize;
//文件下载地址
@property(nonatomic,strong)NSString *materialurl;

//文件类型
@property(nonatomic,assign)FileType type;

//关联议程id
@property(nonatomic,strong)NSString *agendaID;
//文件本地存放路径
@property(nonatomic,strong)NSString *filePath;
//文件下载状态
@property(nonatomic,assign)FileDownLoadType loadType;
//文件已读状态
@property(nonatomic,assign)FileReadType readtype;


#pragma mark - BY HYR -2018-2-14
/**
 *    @brief    标示文件的上一次阅读页码
 */
@property (nonatomic, assign) int lastReadPage;

/**
 *    @brief    标示 批注文件存储位置
 */
@property(nonatomic, copy) NSString *remarkPath;


#pragma mark - end


-(instancetype)initWithDic:(NSDictionary*)dic AndagendaID:(NSString*)agendaID;
-(instancetype)initWithAgendaID:(NSString*)agendaID Withmaterialid:(NSString*)materialid;
@end
