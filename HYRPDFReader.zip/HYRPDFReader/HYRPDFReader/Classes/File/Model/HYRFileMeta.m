//
//  HYRFileMeta.m
//  HYRPDFReader
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/26.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import "HYRFileMeta.h"

@implementation HYRFileMeta

//-(instancetype)initWithDic:(NSDictionary*)dic AndagendaID:(NSString*)agendaID{
//    self = [super init];
//    if(self){
//        if (![[dic objectForKey:@"createtime"] isKindOfClass:[NSNull class]])
//        {
//            self.createtime = [dic objectForKey:@"createtime"];
//        }
//        else{
//            self.createtime = @"";
//        }
//        if (![[dic objectForKey:@"materialIdentification"] isKindOfClass:[NSNull class]])
//        {
//            self.materialIdentification = [dic objectForKey:@"materialIdentification"];
//        }
//        else{
//            self.materialIdentification = @"";
//        }
//        if (![[dic objectForKey:@"materialid"] isKindOfClass:[NSNull class]])
//        {
//            self.materialid = [dic objectForKey:@"materialid"];
//        }
//        else{
//            self.materialid = @"";
//        }
//        if (![[dic objectForKey:@"materialname"] isKindOfClass:[NSNull class]])
//        {
//            self.materialname = [dic objectForKey:@"materialname"];
//        }
//        else{
//            self.materialname = @"";
//        }
//        if (![[dic objectForKey:@"materialsize"] isKindOfClass:[NSNull class]])
//        {
//            self.materialsize = [[dic objectForKey:@"materialsize"] unsignedIntegerValue];
//        }
//        else{
//            self.materialsize = 0;
//        }
//        if (![[dic objectForKey:@"materialurl"] isKindOfClass:[NSNull class]])
//        {
//            self.materialurl = [dic objectForKey:@"materialurl"] ;
//        }
//        else{
//            self.materialurl = @"";
//        }
//        if ([dic objectForKey:@"issignature"]&&![[dic objectForKey:@"issignature"] isKindOfClass:[NSNull class]]){
//            self.type = [[dic objectForKey:@"issignature"] integerValue];
//        }
//        
//        self.agendaID = agendaID;
//        
////        NSArray*arr= [[DataBaseManager dataBaseManager] selectTableDataModel:self WithSQLlaunge:[NSString stringWithFormat:@"select * from FileTable where agendaID='%@' and materialid='%@'",self.agendaID,self.materialid]];
////        if (arr.count<=0) {
////            [[DataBaseManager dataBaseManager] InsertTable:self];
////
////        }else{
//#pragma mark - 取出本地手动添加的属性  因为这些不是服务器传来的 - BY HYR 2018-2-14
//            HYRFileMeta *detealmeta = (HYRFileMeta*)arr[0];
//            
//            if (detealmeta.lastReadPage) {
//                self.lastReadPage = detealmeta.lastReadPage;
//            }else{
//                self.lastReadPage = 0;
//            }
//            
//            if (detealmeta.remarkPath) {
//                self.remarkPath = detealmeta.remarkPath;
//            }else{
//                self.remarkPath = @"";
//            }
////            [[DataBaseManager dataBaseManager] updateTableDataModel:self];
////        }
//        //还愿本地存储对象
////        if(arr.count>0){
//            HYRFileMeta *detealmeta = (HYRFileMeta*)arr[0];
//            self.loadType =  detealmeta.loadType;
//            self.readtype = detealmeta.readtype;
//            if (detealmeta.filePath != nil){
//                self.filePath = detealmeta.filePath;
//            }
////        }
//        
//        
//    }
//    return self;
//}
//-(instancetype)initWithAgendaID:(NSString*)agendaID Withmaterialid:(NSString*)materialid{
//    self = [super init];
//    if(self){
////        NSArray* arr =[[DataBaseManager dataBaseManager] selectTableDataModel:self WithSQLlaunge:[NSString stringWithFormat:@"select * from FileTable where agendaId='%@' and materialid = '%@'",agendaID,materialid]];
////        if(arr.count>0){
//            HYRFileMeta *meta = (HYRFileMeta*)arr[0];
//            self.agendaID = meta.agendaID;
//            self.materialid = meta.materialid;
//            self.createtime = meta.createtime;
//            self.materialname = meta.materialname;
//            self.materialsize = meta.materialsize;
//            self.materialurl = meta.materialurl;
//            self.type = meta.type;
//            self.lastReadPage = meta.lastReadPage;
//            self.materialIdentification = meta.materialIdentification;
//            self.loadType =  meta.loadType;
//            self.readtype = meta.readtype;
//            self.remarkPath = meta.remarkPath;
//            if (meta.filePath != nil){
//                self.filePath = meta.filePath;
////            }
//        }
//    }
//    return self;
//}

@end
