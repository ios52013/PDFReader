//
//  HYRFileTableViewController.m
//  HYRPDFReader
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/25.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import "HYRFileTableViewController.h"
#import "NSString+HYRCategory.h"
#import "HYRFileTool.h"
#import "HYRPDFReaderViewController.h"

static NSString *cellID = @"FileCell";

@interface HYRFileTableViewController () <UITableViewDataSource,UITableViewDelegate>
/***声明 列表 属性***/
@property (nonatomic, strong) UITableView  *myTableView;

/***声明 数据源 属性***/
@property (nonatomic, strong) NSMutableArray  *dataArr;

@end



@implementation HYRFileTableViewController

#pragma mark - LAZY
-(NSMutableArray *)dataArr {
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
        //_dataArr = [HYRFileTool allFileNameWithDirectoryPath:[@"MyPDF" docDir]];
    }
    
    return _dataArr;
}

-(UITableView *)myTableView {
    if (!_myTableView) {
        _myTableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _myTableView.dataSource = self;
        _myTableView.delegate = self;
        [self.view addSubview:_myTableView];
    }
    
    return _myTableView;
}


#pragma mark - 系统自带
- (void)viewDidLoad {
    [super viewDidLoad];
    //处理导航栏
    [self dealWithNavigation];
    //注册cell
    [self.myTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    NSArray *filePathArr = [[NSBundle mainBundle] pathsForResourcesOfType:@".pdf" inDirectory:@"pdfFile"];
    self.dataArr = [filePathArr mutableCopy];
    
}

//处理导航栏
- (void)dealWithNavigation {
    self.navigationItem.title = @"列表显示文件";
    //左侧按钮
    UIBarButtonItem *leftItme = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(leftItemClick:)];
    self.navigationItem.leftBarButtonItem = leftItme;
    
}

//导航栏按钮事件触发的方法
- (void)leftItemClick:(UIBarButtonItem *)itme{
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.textLabel.text = [NSString stringWithFormat:@"%ld:    %@",indexPath.row+1,self.dataArr[indexPath.row]];
    
    return cell;
}

//- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSLog(@"-----%s------",__FUNCTION__);
//    return 160;
//}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"-----%s------",__FUNCTION__);
    return 80;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *fileName = self.dataArr[indexPath.row];
    //fileName = [@"MyPDF" stringByAppendingPathComponent:fileName];
   // NSString *filePath = [fileName docDir];
    NSLog(@"######## %@",fileName);
//    NSData *fileData = [NSData dataWithContentsOfFile:filePath];
    
    HYRPDFReaderViewController *pdfReaderViewController = [[HYRPDFReaderViewController alloc] init];
    pdfReaderViewController.title = self.dataArr[indexPath.row];
    pdfReaderViewController.view.backgroundColor = [UIColor lightGrayColor];
    [pdfReaderViewController showPDFWithFileMetaWithFilePath:fileName andPage:0];
    [self.navigationController pushViewController:pdfReaderViewController animated:YES];
}
@end





