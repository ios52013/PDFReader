//
//  HYRFileTableViewController.h
//  HYRPDFReader
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/25.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import "HYRBaseViewController.h"

@interface HYRFileTableViewController : HYRBaseViewController

@end
