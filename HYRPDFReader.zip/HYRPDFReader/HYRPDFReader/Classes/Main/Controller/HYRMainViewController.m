//
//  HYRMainViewController.m
//  HYRPDFReader
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/25.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import "HYRMainViewController.h"
#import "HYRFileTableViewController.h"
#import "HYRNavigationViewController.h"
#import "NSString+HYRCategory.h"
#import "HYRFileTool.h"


@interface HYRMainViewController ()

@end

@implementation HYRMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *filePath = [@"MyPDF" docDir];
    BOOL isSuccess = [HYRFileTool createDirectoryWithPath:filePath];
    NSLog(@"=======%@",filePath);
    //处理导航栏
    [self dealWithNavigation];
}


//处理导航栏
- (void)dealWithNavigation {
    self.navigationItem.title = @"PDF阅读器";
    //左侧按钮
    UIBarButtonItem *leftItme = [[UIBarButtonItem alloc] initWithTitle:@"TableView" style:UIBarButtonItemStylePlain target:self action:@selector(leftItemClick:)];
    self.navigationItem.leftBarButtonItem = leftItme;
    
    //右侧按钮
    UIBarButtonItem *rightItme = [[UIBarButtonItem alloc] initWithTitle:@"CollectionView" style:UIBarButtonItemStylePlain target:self action:@selector(rightItemClick:)];
    self.navigationItem.rightBarButtonItem = rightItme;
    
}

//导航栏按钮事件触发的方法
- (void)leftItemClick:(UIBarButtonItem *)itme{
    NSLog(@"-----%s------",__FUNCTION__);
    HYRFileTableViewController *fileTableView = [[HYRFileTableViewController alloc] init];
    HYRNavigationViewController *navi = [[HYRNavigationViewController alloc] initWithRootViewController:fileTableView];
    [self presentViewController:navi animated:YES completion:nil];
    
}

- (void)rightItemClick:(UIBarButtonItem *)itme{
    NSLog(@"-----%s------",__FUNCTION__);
}


@end




