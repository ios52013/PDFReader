//
//  HYRFileTool.h
//  QiuQiuNi
//
//  Created by 黄永锐 on 2017/5/31.
//  Copyright © 2017年 LoveQi. All rights reserved.
//  处理文件缓存

#import <Foundation/Foundation.h>

/*
 业务类:以后开发中用来专门处理某件事情,网络处理,缓存处理
 */

@interface HYRFileTool : NSObject

/**
 遍历某个文件夹下的所有文件名

 @param directoryPath 指定文件夹
 @return 该文件夹下的所有文件名
 */
+ (NSMutableArray *)allFileNameWithDirectoryPath:(NSString *)directoryPath;


/**
 根据给定的路径创建文件夹
 
 @param filePath 指定的文件夹路径
 @return 返回yes则代表创建好了  返回no则标识创建文件夹失败
 */
+ (BOOL)createDirectoryWithPath:(NSString *)filePath;

/**
 *  获取文件夹尺寸
 *
 *  @param directoryPath 文件夹路径
 *
 *  @return 返回文件夹尺寸
 */
+ (void)getFileSize:(NSString *)directoryPath completion:(void(^)(NSInteger))completion;


/**
 *  删除文件夹所有文件
 *
 *  @param directoryPath 文件夹路径
 */
+ (void)removeDirectoryPath:(NSString *)directoryPath;


/**
 * 写入文件
 */
+ (void)writeToThePlist:(NSArray *)array andFilePath:(NSString *)filePath;

/**
 * 数组序列化
 */
+ (void)archerTheArr:(NSArray *)array andFilePath:(NSString *)filePath;

/**
 * 反序列化
 */
+ (NSArray *)unArchiverThePlistFilePath:(NSString *)filePath;

/**
 * 删除归档文件
 */
+ (void )removeThePlistFilePath:(NSString *)filePath;


@end
