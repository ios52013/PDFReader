//
//  UIDevice+DZDevice.h
//  PACM_ipad
//
//  Created by 钟文成(外包) on 2018/1/12.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <UIKit/UIKit.h>



@interface UIDevice (DZDevice)
+(void)switchOrientation:(UIInterfaceOrientation)interfaceOrientation;
@end
