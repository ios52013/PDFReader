//
//  UIDevice+DZDevice.m
//  PACM_ipad
//
//  Created by 钟文成(外包) on 2018/1/12.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//
/*
   控制死变态的横屏和竖屏
 */
#import "UIDevice+DZDevice.h"
@implementation UIDevice (DZDevice)

+ (void)switchOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    NSNumber *resetOrientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationUnknown];
    
    [[UIDevice currentDevice] setValue:resetOrientationTarget forKey:@"orientation"];
    
    NSNumber *orientationTarget = [NSNumber numberWithInt:interfaceOrientation];
    
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
    
}





@end
