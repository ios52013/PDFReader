//
//  UIButton+HYRButton.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/1/30.
//  Copyright © 2018年 黄永锐. All rights reserved.
//

#import "UIButton+HYRButton.h"

@implementation UIButton (HYRButton)
/**
 *    @brief    构造button的工厂方法
 *
 *    @param     frame     button的尺寸和位置
 *    @param     title     button的标题
 *    @param     normalImage     正常状态下的背景图片
 *    @param     highlightImage     高亮的背景图片
 *    @param     selectedImage     选择后的背景图片
 *    @param     font     字体
 *    @param     target     目标对象
 *    @param     action     响应方法
 *    @param     controlEvent     响应事件
 *
 *    @return    工厂方法构建的autorelease的button对象
 */
+ (UIButton *)buttonWithFrame:(CGRect)frame
                        title:(NSString *)title
                  normalImage:(UIImage *)normalImage
               highlightImage:(UIImage *)highlightImage
                selectedImage:(UIImage *)selectedImage
                         font:(UIFont *)font
                       target:(id)target
                       action:(SEL)action
                 controlEvent:(UIControlEvents)controlEvent
{
    UIButton *button_f = [[UIButton alloc] initWithFrame:frame];
    [button_f setBackgroundColor:[UIColor clearColor]];
    if (title)
        [button_f setTitle:title forState:UIControlStateNormal];
    if (normalImage)
        [button_f setBackgroundImage:normalImage forState:UIControlStateNormal];
    if (highlightImage)
        [button_f setBackgroundImage:highlightImage forState:UIControlStateHighlighted];
    if (selectedImage)
        [button_f setBackgroundImage:selectedImage forState:UIControlStateSelected];
    if (font)
        [button_f.titleLabel setFont:font];
    if (action && target)
        [button_f addTarget:target action:action forControlEvents:controlEvent];
    return button_f;
}

@end
