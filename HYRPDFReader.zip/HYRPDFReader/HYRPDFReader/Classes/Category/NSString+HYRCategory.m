//
//  NSString+HYRCategory.m
//  QiuQiuNi
//
//  Created by 黄永锐 on 2017/6/1.
//  Copyright © 2017年 LoveQi. All rights reserved.
//

#import "NSString+HYRCategory.h"

@implementation NSString (HYRCategory)

/**
 * 将当期字符串拼接到doc目录后面
 */

- (NSString *)docDir{
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    return [path stringByAppendingPathComponent:self];
}

/**
 * 将当期字符串拼接到cache目录后面
 */

- (NSString *)cacheDir{
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    return [path stringByAppendingPathComponent:self];
    
}

/**
 * 将当期字符串拼接到tmp目录后面
 */

- (NSString *)tmpDir{
    
    NSString *path = NSTemporaryDirectory();
    return [path stringByAppendingPathComponent:self];
}


@end
