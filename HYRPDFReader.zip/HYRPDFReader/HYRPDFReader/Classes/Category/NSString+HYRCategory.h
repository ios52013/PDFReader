//
//  NSString+HYRCategory.h
//  QiuQiuNi
//
//  Created by 黄永锐 on 2017/6/1.
//  Copyright © 2017年 LoveQi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HYRCategory)
/**
 * 将当期字符串拼接到doc目录后面
 */

- (NSString *)docDir;

/**
 * 将当期字符串拼接到cache目录后面
 */

- (NSString *)cacheDir;

/**
 * 将当期字符串拼接到tmp目录后面
 */

- (NSString *)tmpDir;

@end
