//
//  HYRMarkView.h
//  标注的底部栏
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/9.
//  Copyright © 2018年 黄永锐(EX-HUANGYONGRUI001). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYRMarkView : UIView

@property (weak, nonatomic) IBOutlet UILabel *sizeLabel;

@property (weak, nonatomic) IBOutlet UIButton *revokeButton;
@property (weak, nonatomic) IBOutlet UIButton *minSizeButton;
@property (weak, nonatomic) IBOutlet UIButton *midSizeButton;
@property (weak, nonatomic) IBOutlet UIButton *maxSizeButton;

@property (weak, nonatomic) IBOutlet UILabel *colorLabel;
@property (weak, nonatomic) IBOutlet UIButton *redButton;
@property (weak, nonatomic) IBOutlet UIButton *grayButton;
@property (weak, nonatomic) IBOutlet UIButton *blueButton;


@end
