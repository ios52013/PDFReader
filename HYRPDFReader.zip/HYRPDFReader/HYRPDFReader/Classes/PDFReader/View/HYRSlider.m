//
//  HYRSlider.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/8.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "HYRSlider.h"

@implementation HYRSlider


// 控制slider的宽和高，这个方法才是真正的改变slider滑道的高的
- (CGRect)trackRectForBounds:(CGRect)bounds
{
    return CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}

//-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    NSLog(@"-----%s------",__FUNCTION__);
//   // return self;
//    
//}

//-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
//    NSLog(@"-----%s------",__FUNCTION__);
//
////    return self;
//    return [super hitTest:point withEvent:event];
//}


@end
