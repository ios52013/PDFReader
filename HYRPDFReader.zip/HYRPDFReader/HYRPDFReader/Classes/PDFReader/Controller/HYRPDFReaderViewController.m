//
//  HYRPDFReaderViewController.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//


#ifndef DEBUGX
#define DEBUGX
#endif

/**
 *    @brief    配置普通文字尺寸
 *
 *    @param     font     文字尺寸
 *
 *    @return    普通UIFont对象
 */
#define SYSTEMFONT(font)                [UIFont systemFontOfSize:font]
/**
 *    @brief    小标题颜色
 */
#define SUBTITLE_TEXTCOLOR              [UIColor colorWithRed:204.0/255.0 green:85.0/255.0 blue:0 alpha:1]




#define PDFREADVIEW_DESKTOP_PROTRAIT_X                    17.0
#define PDFREADVIEW_DESKTOP_PROTRAIT_Y                    914.0
#define PDFREADVIEW_DESKTOP_PROTRAIT_WIDTH          733.0
#define PDFREADVIEW_DESKTOP_LANDSCAPE_X                 20.0
#define PDFREADVIEW_DESKTOP_LANDSCAPE_Y                  658.0
#define PDFREADVIEW_DESKTOP_LANDSCAPE_WIDTH        983.0

#define PDFREADVIEW_DESKTOP_HEIGHT              120

#define PDFREADVIEW_DESKTOPIMAGEVIEW_Y                    44.0
#define PDFREADVIEW_DESKTOPIMAGEVIEW_HEIGHT         40.0

#define PDFREADVIEW_PREVIOUSBTN_X                          40
#define PDFREADVIEW_PREVIOUSBTN_Y                          20
#define PDFREADVIEW_PREVIOUSBTN_WIDTH                      80
#define PDFREADVIEW_PREVIOUSBTN_HEIGHT                     36

#define PDFREADVIEW_PREVIOUSLABEL_X                             82.0
#define PDFREADVIEW_PREVIOUSLABEL_Y                             45.0
#define PDFREADVIEW_PREVIOUSLABEL_WIDTH                   50.0
#define PDFREADVIEW_PREVIOUSLABEL_HEIGHT                  25.0

#define PDFREADVIEW_PAGELABEL_X                                     326.0
#define PDFREADVIEW_PAGELABEL_Y                                20
#define PDFREADVIEW_PAGELABEL_WIDTH                            80
#define PDFREADVIEW_PAGELABEL_HEIGHT                           30.0

#define PDFREADVIEW_PAGEGOTO_PORTRATI_X                   400.0
#define PDFREADVIEW_PAGEGOTO_LANDSCAPE_X                530.0
#define PDFREADVIEW_PAGEGOTO_Y                                20
#define PDFREADVIEW_PAGEGOTO_WIDTH                            120
#define PDFREADVIEW_PAGEGOTO_HEIGHT                           36.0


#define PDFREADVIEW_NEXTLABEL_X                                     602.0
#define PDFREADVIEW_NEXTLABEL_Y                                     45.0
#define PDFREADVIEW_NEXTLABEL_WIDTH                           50.0
#define PDFREADVIEW_NEXTLABEL_HEIGHT                          25.0

#define PDFREADVIEW_NEXTBTN_X                                   649.0
#define PDFREADVIEW_NEXTBTN_Y                                   20.0
#define PDFREADVIEW_NEXTBTN_WIDTH                               80
#define PDFREADVIEW_NEXTBTN_HEIGHT                              36

#define PDFREADVIEW_HANDSIZEVIEW_X                              30.0
#define PDFREADVIEW_HANDSIZEVIEW_Y                               0.0
#define PDFREADVIEW_HANDSIZEVIEW_WIDTH                     182.0
#define PDFREADVIEW_HANDSIZEVIEW_HEIGHT                    64.0

#define PDFREADVIEW_HANDCOLORVIEW_X                            286.0
#define PDFREADVIEW_HANDCOLORVIEW_Y                             0.0
#define PDFREADVIEW_HANDCOLORVIEW_WIDTH                   275.0
#define PDFREADVIEW_HANDCOLORVIEW_HEIGHT                  64.0

#define PDFREADVIEW_HANDWITHDRAWBTN_X                       650.0
#define PDFREADVIEW_HANDWITHDRAWBTN_Y                        18.0
#define PDFREADVIEW_HANDWITHDRAWBTN_WIDTH              54.0
#define PDFREADVIEW_HANDWITHDRAWBTN_HEIGHT             62.0

#define PDFREADVIEW_CONTENTVIEW_X                                   0.0
#define PDFREADVIEW_CONTENTVIEW_Y                                   0.0
#define PDFREADVIEW_CONTENTVIEW_PORTRAIT_WIDTH      768.0
#define PDFREADVIEW_CONTENTVIEW_LANDSCAPE_WIDTH    1024.0
#define PDFREADVIEW_CONTENTVIEW_PORTRAIT_HEIGHT      1004.0
#define PDFREADVIEW_CONTENTVIEW_LANDSCAPE_HEIGHT    748.0

#define PAGING_VIEWS 3

#define TOOLBAR_HEIGHT 44.0f
#define PAGEBAR_HEIGHT 48.0f

#define TAP_AREA_SIZE 48.0f


#define  kMinSizeButtonTag            201
#define  kMidSizeButtonTag            202
#define  kMaxSizeButtonTag            203

#define  kRedColorButtonTag           204
#define  kGrayColorButtonTag          205
#define  kBlueColorButtonTag          206
#define  kBlackColorButtonTag         207

#define kHandSizeViewTag               401
#define kHandColorViewTag              402

//标注按钮 和 标注目录按钮的tag
#define kCommentButtonTag               501
#define kCommentMenuButtonTag           502



//批注底部栏的
#define PDFMARKVIEW_WIDTH       kScreenWidth
#define PDFMARKVIEW_HEIGHT      68
#define PDFMARKVIEW_X           0
#define PDFMARKVIEW_Y           kScreenHeight-PDFMARKVIEW_HEIGHT

//撤销按钮
#define PDFMARKVIEW_CANCLEBTN_X         40
#define PDFMARKVIEW_CANCLEBTN_Y         10
#define PDFMARKVIEW_CANCLEBTN_WIDTH     80
#define PDFMARKVIEW_CANCLEBTN_HEIGHT    40

//笔画大小
#define PDFMARKVIEW_SIZELABEL_X         40
#define PDFMARKVIEW_SIZELABEL_Y         10
#define PDFMARKVIEW_SIZELABEL_WIDTH     50
#define PDFMARKVIEW_SIZELABEL_HEIGHT    40





#import "HYRPDFReaderViewController.h"
//#import "AgendaViewController.h"
#import "BookMarkViewController.h"
#import "AppDelegate.h"
#import "UIButton+HYRButton.h"
//#import "DataBaseManager.h"
#import "UIImage+HYRComponent.h"
//#import "ZNavigationBar.h"
//#import "ComstomNaviControllerViewController.h"
#import "UIColor+HYRComponent.h"
#import "HYRSlider.h"
#import "HYRMarkView.h"
#import "UIDevice+DZDevice.h"
#import "UIView+Extension.h"


static NSInteger kPageLabelTag = 101;                  //显示当前页码的文本框
static NSInteger kPreDataBtnTag = 102;              //上一份资料按钮
static NSInteger kNextDataBtnTag = 103;           //下一份资料按钮
static NSInteger kPreDataLabelTag = 104;
static NSInteger kNextDataLabelTag = 105;


@interface HYRPDFReaderViewController ()//<ComstomNaviDelegate>
/***声明 导航栏 属性***/
//@property (nonatomic, strong) ComstomNaviControllerViewController *cusNavigationController;
/***声明 进度条的值 属性***/
@property (nonatomic, strong) HYRSlider  *slider;
/***声明 sv的frame 属性***/
@property (nonatomic, assign) CGRect theViewFrame;

@end

@implementation HYRPDFReaderViewController

- (id)init {
    if (self = [super init]) {
        [self initAllArrayAndDictionary];
        
        self.theViewFrame = CGRectMake(0, 80, kScreenWidth, kScreenHeight-80-120);
        _currentPage = -1;
        _contentViews = [NSMutableDictionary new];
    }
    return self;
}

#pragma mark =======    加载界面     =======

/**
 *    @brief    加载顶部批注、阅读模式按钮
 */
- (NSArray *)addNavRightSideButton {
    
    float buttonWidth = 130;
    float buttonHeight = 30;
    CGRect frame = CGRectMake(kScreenWidth - buttonWidth - 20, 80 - buttonHeight - 13, buttonWidth, buttonHeight);
    //按钮图片
    UIImage *normalImage = [UIImage imageNamed:@"Com_comment"];
   
    _dataLookoverModelButton = [[UIButton alloc] initWithFrame:frame];
    [_dataLookoverModelButton setTag:kCommentButtonTag];
    [_dataLookoverModelButton setTitle:NSLocalizedString(@"Comment", @"这是批注按钮") forState:UIControlStateNormal];
    //设置图片
    [_dataLookoverModelButton setImage:normalImage forState:UIControlStateNormal];
    [_dataLookoverModelButton.titleLabel setFont:[UIFont systemFontOfSize:16]];

//    self.cusNavigationController.titlelabel.frame;
    

    //CGRectGetMaxX(self.cusNavigationController.titlelabel.frame) + 20
    //我的批注
//    frame = CGRectMake(kScreenWidth - buttonWidth - _dataLookoverModelButton.width,
//                       80 - buttonHeight - 13,
//                       buttonWidth,
//                       buttonHeight);
    
    UIImage *normalImage2 = [UIImage imageNamed:@"Com_pizhumenu"];
    _bookMarkButton = [[UIButton alloc] initWithFrame:frame];
    [_bookMarkButton setTag:kCommentMenuButtonTag];
    [_bookMarkButton setTitle:NSLocalizedString(@"MyComment", @"这是我的批注") forState:UIControlStateNormal];
    [_bookMarkButton setImage:normalImage2 forState:UIControlStateNormal];
    [_bookMarkButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
    //[_bookMarkButton setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin];
    
    
    NSArray *rightButtonArray = @[_dataLookoverModelButton,_bookMarkButton];
   
    return rightButtonArray;
}


#pragma mark - 加载顶部导航栏
- (void)addNavgationButton {
    
//    self.cusNavigationController= [ComstomNaviControllerViewController CreateComstomNvTiltleName:NSLocalizedString(@"关于会议的会议资料", nil) WithTitleFont: [UIFont fontWithName:@"PingFangSC-Regular" size:20.0] WithLeftButtons:nil WithRightButtons:[self addNavRightSideButton]];
//    self.cusNavigationController.delegate = self;
//
//    [self.view addSubview:self.cusNavigationController];
//
//    [self.cusNavigationController setBanckGroundCorlor:[UIColor colorWithHexString:@"#565656" alpha:1.0] WithAplphl:1.0];
//    [self.cusNavigationController setTiletelabelWithArgmernt:NSTextAlignmentCenter];
//    [self.cusNavigationController setTiltelabelWithCorlor:[UIColor whiteColor]];
    
    self.navigationItem.title = self.title;

}

/**
 *    @brief    代理方法
 */
#pragma mark - 左侧 导航按钮事件
- (void)CickRetuned:(id)obj{
    
    UIButton *button = (UIButton *)obj;
    //根据按钮标题来决定处理的事件
    NSString *title = button.currentTitle;
    
    if ([title isEqualToString:@"返回"] || [title isEqualToString:@"Return"] ) {
        // 屏幕方向是竖着处理
        if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
            [UIDevice switchOrientation:UIInterfaceOrientationLandscapeRight];
        }
        
        //保存批注
        [self saveHandDataToLocal];
        
        //判断当前界面是push过来的还是present过来的，因为会议资料那里是present过来的
        if (self.presentationController) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        
        //判断是否有系统的导航栏
        if(self.navigationController){
            [self.navigationController popViewControllerAnimated:YES];
        }else{
//            [app.navigation popViewControllerAnimated:YES];
        }
        
        if (_isPushFromBookMarkView && self.imageTouchHandData){
            //如果当前页面的前一个页面是我的批注，并且在当前页面做了批注，则需要及时更新批注，以便在我的批注页面能能够及时显示最新的批注
            BookMarkViewController *bookMarkViewController = [[BookMarkViewController alloc] init];

            [bookMarkViewController showBookMarkWithFileMeta:_curMaterial];
        }
        
    }else{
        //如果按钮此时的标题是退出
        //应该判断用户是否已经有批注了
        //获取更新的批注内容
        NSData *touchHandData = [_curReaderContentView.noteView saveHandImageData];
        
        //存在新的笔迹内容 就提示是否需要退出  否则直接退出
        if (touchHandData) {
            //弹出警告框
            UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reminder", nil) message:NSLocalizedString(@"Comment unsaved,Exit?", nil) preferredStyle:UIAlertControllerStyleAlert];
            
            //直接退出
            //如果有标注 就直接放弃所有标注
            //如果没有标注 就放弃编辑的状态
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Continue to quit", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
                _curDataLookoverModel = DataLookoverModelRead;
                [_readModelView setHidden:NO];
                [_remarkModelView setHidden:YES];
                //“退出”按钮  改变图片 文字变成 “返回”
                //第一次点击退出 是抹掉所有批注 再次点击才变按钮
//                [self.cusNavigationController setReturnButtonTiltle:NSLocalizedString(@"Return", nil) Withimg:[UIImage imageNamed:@"back"]];
                //保存按钮 变成 标注按钮
                [_dataLookoverModelButton setTitle:NSLocalizedString(@"Comment", nil) forState:UIControlStateNormal];
                [_dataLookoverModelButton setImage:[UIImage imageNamed:@"Com_comment"] forState:UIControlStateNormal];
                //清空未保存的笔画
                //释放旧的笔迹
                if (self.imageTouchHandData) {
                    _imageTouchHandData = nil;
                }
                //变成不能编辑的状态
                [_curReaderContentView hideNoteView:_currentViewHandImage.image];
                // 判断实际缩放
                _curReaderContentView.actualScale = _curReaderContentView.actualScale > 30 ? 1: _curReaderContentView.actualScale ;
                //
                _selectedHandSize /= _curReaderContentView.actualScale;
                
                _curReaderContentView = nil;
                [_curReaderContentView setTheContainerViewBackgroundImage:_currentViewMicroImage.image];
                _theScrollView.scrollEnabled = YES;
            }];
            
            //保存批注
            UIAlertAction *saveCommentAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Save Comment", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                //
                [self saveComment:obj];
            }];
            
            [alertVC addAction:cancelAction];
            [alertVC addAction:saveCommentAction];
            
            [self presentViewController:alertVC animated:YES completion:nil];
            
        }else{
            //如果还没有批注 那就直接把按钮标题切换回来
            _curDataLookoverModel = DataLookoverModelRead;
            [_readModelView setHidden:NO];
            [_remarkModelView setHidden:YES];
            //变成不能编辑的状态
            [_curReaderContentView hideNoteView:_currentViewHandImage.image];
            // 判断实际缩放
            _curReaderContentView.actualScale = _curReaderContentView.actualScale > 30 ? 1: _curReaderContentView.actualScale ;
            //
            _selectedHandSize /= _curReaderContentView.actualScale;
            
            _curReaderContentView = nil;
            [_curReaderContentView setTheContainerViewBackgroundImage:_currentViewMicroImage.image];
            _theScrollView.scrollEnabled = YES;
            
            //“退出”按钮  改变图片 文字变成 “返回”
//            [self.cusNavigationController setReturnButtonTiltle:NSLocalizedString(@"Return", nil) Withimg:[UIImage imageNamed:@"back"]];
            //保存按钮 变成 标注按钮
            [_dataLookoverModelButton setTitle:NSLocalizedString(@"Comment", nil) forState:UIControlStateNormal];
            [_dataLookoverModelButton setImage:[UIImage imageNamed:@"Com_comment"] forState:UIControlStateNormal];
            
        }
    
        
    }
   
    
}

/**
 *    @brief    代理方法
 */
#pragma mark - 右侧导航按钮事件
- (void)CickNaviButton:(UIButton*)button{
    
    if (button.tag == kCommentButtonTag) {
        //点击批注按钮
        [self modelTypeBtnClick:button];
    }else{
        // - 我的批注
        [self bookMarkBtnClick:button];
    }
    
}




#pragma mark - 加载pdf页码跳转页面

- (void)loadPagegotoView {
    _pageGotoView = [[UIView alloc] initWithFrame:CGRectMake(
                                                             (kScreenWidth - PDFREADVIEW_PAGEGOTO_WIDTH)*.5,
                                                             PDFREADVIEW_PAGEGOTO_Y,
                                                             PDFREADVIEW_PAGEGOTO_WIDTH,
                                                             PDFREADVIEW_PAGEGOTO_HEIGHT)];
    [_pageGotoView setBackgroundColor:[UIColor clearColor]];
    [_pageGotoView setAutoresizingMask:UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleLeftMargin];
    
    //文本输入框
    UITextField *pagenumberTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 50, 36)];
    _curTextField = pagenumberTextField;
    pagenumberTextField.layer.cornerRadius = 8.0;
    pagenumberTextField.layer.masksToBounds = YES;
    [pagenumberTextField setDelegate:self];
    [pagenumberTextField setBackgroundColor:[UIColor colorWithHexString:@"7A7A7A" alpha:1.0]];
    [pagenumberTextField setTextColor:[UIColor whiteColor]];
    [pagenumberTextField setFont:[UIFont systemFontOfSize:20.0]];
    [pagenumberTextField setTextAlignment:NSTextAlignmentCenter];
    [pagenumberTextField setKeyboardType:UIKeyboardTypeNumberPad];
    [pagenumberTextField setReturnKeyType:UIReturnKeyGo];
    [_pageGotoView addSubview:pagenumberTextField];
   
    //显示页码
    UILabel *pageLabel = [[UILabel alloc] initWithFrame:CGRectMake(60,3,60,30)];
    [pageLabel setTag:kPageLabelTag];
    [pageLabel setBackgroundColor:[UIColor clearColor]];
    [pageLabel setTextAlignment:NSTextAlignmentLeft];
    [pageLabel setTextColor:[UIColor whiteColor]];
    [pageLabel setFont:[UIFont systemFontOfSize:20.0]];
    pageLabel.text = [NSString stringWithFormat:@"/ %d",_totalPages];
    [pageLabel setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin];
    [_pageGotoView addSubview:pageLabel];
    
    [_readModelView addSubview:_pageGotoView];
}

#pragma mark - 滑块进度条事件触发的方法
- (void)sliValueChange:(HYRSlider *)slider {
    NSLog(@"-----滑块进度条----%lf",slider.value);
    NSInteger currentP = slider.value * _totalPages;
    NSLog(@"--------%ld",currentP);
    
    [self showDocumentPage:(currentP)];
    if (currentP == _totalPages) {
        slider.value = 1.0;
        [slider setNeedsDisplay];
    }
}

#pragma mark - 加载阅读模式上的辅助功能页面

- (void)loadReadModelView {
    
    HYRSlider *slider = [[HYRSlider alloc] initWithFrame:CGRectMake(40, PDFREADVIEW_DESKTOP_HEIGHT - 32-8, kScreenWidth - 2*40, 8)];
    [slider setMinimumTrackTintColor:[UIColor colorWithHexString:@"FF6B32" alpha:1.0]];
    [slider setMaximumTrackTintColor:[UIColor colorWithHexString:@"8B8B8B" alpha:1.0]];
    //自动调整slider的宽度，保证左边距和右边距不变
    [slider setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [slider addTarget:self action:@selector(sliValueChange:) forControlEvents:UIControlEventValueChanged];
    [_readModelView addSubview:slider];
    _slider = slider;
    
    UIButton *previousBtn = [[UIButton alloc] initWithFrame:CGRectMake(PDFREADVIEW_PREVIOUSBTN_X,
                                                                       PDFREADVIEW_PREVIOUSBTN_Y,
                                                                       PDFREADVIEW_PREVIOUSBTN_WIDTH,
                                                                       PDFREADVIEW_PREVIOUSBTN_HEIGHT)];
    [previousBtn setTitle:NSLocalizedString(@"Previous", @"上一页的按钮") forState:UIControlStateNormal];
    
    [previousBtn setTag:kPreDataBtnTag];
    //自动调整previousBtn与父视图右边距，以保证左边距不变
    [previousBtn setAutoresizingMask:UIViewAutoresizingFlexibleRightMargin];
    [previousBtn addTarget:self action:@selector(preBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_readModelView addSubview:previousBtn];
    
    //页码
    [self loadPagegotoView];
    
    //下一页
    UIButton *nextBtn = [[UIButton alloc] initWithFrame:CGRectMake(
                                                                   kScreenWidth - PDFREADVIEW_NEXTBTN_WIDTH - 40,
                                                                   PDFREADVIEW_NEXTBTN_Y,
                                                                   PDFREADVIEW_NEXTBTN_WIDTH,
                                                                   PDFREADVIEW_NEXTBTN_HEIGHT)];
    
    [nextBtn setTag:kNextDataBtnTag];
    [nextBtn setTitle:NSLocalizedString(@"Next", @"下一页的按钮") forState:UIControlStateNormal];
    [nextBtn setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin];
    [nextBtn addTarget:self action:@selector(nextBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_readModelView addSubview:nextBtn];
 
    
}


#pragma mark - 加载批注模式下的辅助工具页面

- (void)loadRemarkModelView {
    
    
    HYRMarkView *markView = [[NSBundle mainBundle] loadNibNamed:@"HYRMarkView" owner:self options:nil][0];
    markView.frame = CGRectMake(PDFMARKVIEW_X, PDFMARKVIEW_Y, PDFMARKVIEW_WIDTH, PDFMARKVIEW_HEIGHT);
    _remarkModelView = markView;
    [_remarkModelView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [self.view addSubview:_remarkModelView];
    
    //撤销上一步的批注
    [_remarkModelView.revokeButton setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin];
    [_remarkModelView.revokeButton addTarget:self action:@selector(withDrawBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_remarkModelView.revokeButton setTitle:NSLocalizedString(@"Revoke", nil) forState:UIControlStateNormal];
    
    
    //画笔大小
    [_remarkModelView.sizeLabel setText:NSLocalizedString(@"Size", nil)];
    [_remarkModelView.minSizeButton addTarget:self action:@selector(sizeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    //设置默认笔画
    [_remarkModelView.minSizeButton setSelected:YES];
    [_remarkModelView.midSizeButton addTarget:self action:@selector(sizeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_remarkModelView.maxSizeButton addTarget:self action:@selector(sizeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    //颜色按钮
    [_remarkModelView.colorLabel setText:NSLocalizedString(@"Color", nil)];
    [_remarkModelView.redButton addTarget:self action:@selector(colorBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    //设置默认颜色
    [_remarkModelView.redButton setSelected:YES];
    [_remarkModelView.grayButton addTarget:self action:@selector(colorBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_remarkModelView.blueButton addTarget:self action:@selector(colorBtnClick:) forControlEvents:UIControlEventTouchUpInside];

    //
    [_remarkModelView.minSizeButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_remarkModelView.midSizeButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_remarkModelView.maxSizeButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
   
    //进来的时候是隐藏d
    [_remarkModelView setHidden:YES];
    
}


#pragma mark - 底部栏  pdf辅助功能页面
- (void)loadReadModeltopView{
   
    _readModelView = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                            kScreenHeight-PDFREADVIEW_DESKTOP_HEIGHT,
                                                            kScreenWidth,
                                                            PDFREADVIEW_DESKTOP_HEIGHT)];
    //自动调整view的宽度，保证左边距和右边距不变
    [_readModelView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [_readModelView setBackgroundColor:[UIColor colorWithHexString:@"#595959" alpha:1.0]];
    
    //加载阅读模式的底部栏
    [self loadReadModelView];
    
   
    [self.view addSubview:_readModelView];
}

/**
 *    @brief    加载所有pdf内容view的一个容器，用来控制pdf内容view的切换
 */
- (void)loadScrollView {
    _theScrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    _theScrollView.scrollsToTop = NO;
    _theScrollView.bounces = NO;
    _theScrollView.pagingEnabled = YES;
    _theScrollView.delaysContentTouches = NO;
    _theScrollView.showsVerticalScrollIndicator = NO;
    _theScrollView.showsHorizontalScrollIndicator = NO;
    _theScrollView.contentMode = UIViewContentModeRedraw;
    _theScrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _theScrollView.backgroundColor = [UIColor clearColor];
    _theScrollView.userInteractionEnabled = YES;
    _theScrollView.autoresizesSubviews = NO;
    _theScrollView.delegate = self;
//    _theScrollView.frame = CGRectMake(0, 80, kScreenWidth, kScreenHeight-80-120);
    [self.view addSubview:_theScrollView];
}




#pragma mark - 竖屏布局

- (void)relayoutElementsForPortrait {
    
//    CGFloat desktopView_Y = 0;
//    UIView *keyboard = [Globle keyboard];
//    if (keyboard)
//        desktopView_Y = PDFREADVIEW_DESKTOP_PROTRAIT_Y - 262.0;
//    else
//        desktopView_Y = PDFREADVIEW_DESKTOP_PROTRAIT_Y;
    
    float buttonWidth = 130;
    float buttonHeight = 30;
    
    //导航栏
//    self.cusNavigationController.titlelabel.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2-80, 80-16-28, 160, 28);
    
    _dataLookoverModelButton.frame =  CGRectMake(kScreenWidth - buttonWidth - 20, 80 - buttonHeight - 13, buttonWidth, buttonHeight);
    //我的批注
    _bookMarkButton.frame =  CGRectMake(
                                        kScreenWidth - buttonWidth - _dataLookoverModelButton.width,
                                        80 - buttonHeight - 13,
                                        buttonWidth,
                                        buttonHeight);
    //阅读底部栏
    [_readModelView setFrame:CGRectMake(0,
                                      kScreenHeight-PDFREADVIEW_DESKTOP_HEIGHT,
                                      kScreenWidth,
                                      PDFREADVIEW_DESKTOP_HEIGHT)];
    //标注底部栏
    [_remarkModelView setFrame:CGRectMake(PDFMARKVIEW_X, PDFMARKVIEW_Y, PDFMARKVIEW_WIDTH, PDFMARKVIEW_HEIGHT)];
    
    
}

/**
 *    @brief    横屏布局
 */
- (void)relayoutElementsForLandscape {
//    CGFloat desktopView_Y = 0;
//    UIView *keyboard = [Globle keyboard];
//    if (keyboard)
//        desktopView_Y = PDFREADVIEW_DESKTOP_LANDSCAPE_Y - 350.0;
//    else
//        desktopView_Y = PDFREADVIEW_DESKTOP_LANDSCAPE_Y;
    
    float buttonWidth = 130;
    float buttonHeight = 30;
    
    //导航栏
//    self.cusNavigationController.titlelabel.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2-160, 80-16-28, 320, 28);
    _dataLookoverModelButton.frame =  CGRectMake(kScreenWidth - buttonWidth - 20, 80 - buttonHeight - 13, buttonWidth, buttonHeight);
    //我的批注
//    _bookMarkButton.frame =  CGRectMake(
//                                        kScreenWidth - buttonWidth - _dataLookoverModelButton.width,
//                                        80 - buttonHeight - 13,
//                                        buttonWidth,
//                                        buttonHeight);
    //阅读底部栏
    [_readModelView setFrame:CGRectMake(0,
                                      kScreenHeight-PDFREADVIEW_DESKTOP_HEIGHT,
                                      kScreenWidth,
                                      PDFREADVIEW_DESKTOP_HEIGHT)];
    //标注底部栏
    [_remarkModelView setFrame:CGRectMake(PDFMARKVIEW_X, PDFMARKVIEW_Y, PDFMARKVIEW_WIDTH, PDFMARKVIEW_HEIGHT)];
    
    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark =======    逻辑处理     =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark ----  公有接口  ---HYR-2018-2-12

#pragma mark - 展示指定的pdf阅读资料
- (void)showPDFWithFileMetaWithFilePath:(NSString *)filePath andPage:(int)page {
    [self clearMemoryBeforeShowPDF];
    [self setPDFDocumentReferenceWithMeterialPath:filePath];
    if (!_pdfDocumentRef) {//pdf文件打开失败
        [_readModelView setHidden:YES];
        [self.view bringSubviewToFront:self.navigationController.navigationBar];
        //提示错误信息
        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"Fail to open file", nil)];
        [SVProgressHUD dismissWithDelay:1.0];
        return;
        
    }else{
        //pdf文件打开成功
        [_readModelView setHidden:NO];
        
    }
    
    _totalPages = CGPDFDocumentGetNumberOfPages(_pdfDocumentRef);
    
    [self showDocument:[NSNumber numberWithInt:page]];
    
    [self updateScrollViewContentViews];
}


/**
 *    @brief    根据需要打开的资料，建立一个资料操作句柄
 *
 *    @param     needOpenMaterial     需要打开的资料文件
 */
- (void)setPDFDocumentReferenceWithMeterialPath:(NSString *)needOpenMaterialPath {
    
    NSData *fileData = [NSData dataWithContentsOfFile:needOpenMaterialPath];
    CFDataRef dataRef = (__bridge_retained CFDataRef)(fileData);
    CGDataProviderRef dataProviderRef = CGDataProviderCreateWithCFData(dataRef);
    
    _pdfDocumentRef = CGPDFDocumentCreateWithProvider(dataProviderRef);
    
    CGDataProviderRelease(dataProviderRef);
    
}







#pragma mark - 展示指定的pdf阅读资料
- (void)showPDFWithFileMeta:(id)meta andPage:(int)page {

    [self clearMemoryBeforeShowPDF];
   
    [self prepareNecessaryDataBeforeShowPDFWithFileMeta:meta];
    
    //如果不是从我的批注页面进入，则从本地数据库获取上次最后查看的页码
    if (!_preViewIsSelectedBookMarkView) {
        
        if ([meta isKindOfClass:[HYRFileMeta class]]) {
            page = _curFileMeta.lastReadPage;
        }

        
    }
    
    
    [self setPDFDocumentReferenceWithMeterial:_curMaterial];
    
    
    if (!_pdfDocumentRef) {//pdf文件打开失败
        [_readModelView setHidden:YES];
        [self.view bringSubviewToFront:self.navigationController.navigationBar];//确保toolbar在最前端显示，保证上面的按钮能够响应事件
#warning TODO - 需要隐藏书签和批注按钮

        //提示错误信息
        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"Fail to open file", nil)];
        [SVProgressHUD dismissWithDelay:1.0];
        return;
        
    }else{
        //pdf文件打开成功
        [_readModelView setHidden:NO];//显示tabBar
#warning TODO - 需要显示书签和批注按钮
       
    }
    
    _totalPages = CGPDFDocumentGetNumberOfPages(_pdfDocumentRef);
    
    [self showDocument:[NSNumber numberWithInt:page]];
    
    [self updateScrollViewContentViews];
}



#pragma mark - 在打开一份资料文件前做的一些前期准备工作
- (void)prepareNecessaryDataBeforeShowPDFWithFileMeta:(id)meta {
    //默认显示上一份，下一份按钮（可能上次离开阅读页面时，按钮被隐藏）
    [(UIView *)[_readModelView viewWithTag:kPreDataBtnTag] setHidden:NO];
    [(UIView *)[_readModelView viewWithTag:kPreDataLabelTag] setHidden:NO];
    [(UIView *)[_readModelView viewWithTag:kNextDataBtnTag] setHidden:NO];
    [(UIView *)[_readModelView viewWithTag:kNextDataLabelTag] setHidden:NO];
    
    //默认设置当前pdf页码数为-1，因为页码数是从0开始
    _currentPage = -1;
    [_theScrollView setContentSize:CGSizeZero];
    _lastAppearSize = CGSizeZero;
    
    // 判断文件类型
    //普通会议文件
    if ([meta isKindOfClass:[HYRFileMeta class]]) {
        //要查看的文件
        HYRFileMeta *material = (HYRFileMeta *)meta;
        //根据文件id去数据库里面查询相应的文件
//        FileMeta *downloadedMaterial = (FileMeta *)[[DataBaseManager dataBaseManager] materialFromSqliteWithMaterial:material];
        
//        self.cusNavigationController.titlelabel.text = downloadedMaterial.materialname;
        _curFileMeta = material;
        //保存当前文件
//        _curMaterial = downloadedMaterial;
        
        //获取存储在本地的标签数据源
        [self setTagMutableArrayDataSource:_curMaterial];
        
    }
    

   
    
    
}


#pragma mark - 获取存储在本地的标签数据源
- (void)setTagMutableArrayDataSource:(id)curMeta {
    if (_tagMutableArray)
        _tagMutableArray = nil;
    
    // 判断文件类型
    if ([curMeta isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *meta = (HYRFileMeta *)curMeta;
        
//        NSString *remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:meta.materialid];
//        _tagMutableArray = [[NSMutableArray alloc] initWithArray:[DataBaseManager loadDataFromFile:remarkPath]];
//
//         //导航栏的相应按钮隐藏和显示
//        if ([_tagMutableArray count] == 0) {
//            _bookMarkButton.hidden = YES;
//        }else {
//            _bookMarkButton.hidden = NO;
//        }
        
    }
    

    
}


/**
 *    @brief    根据需要打开的资料，建立一个资料操作句柄
 *
 *    @param     needOpenMaterial     需要打开的资料文件
 */
- (void)setPDFDocumentReferenceWithMeterial:(id)needOpenMaterial {
    
    //将本地文件数据根据cyberArk获取的密钥进行解密
    NSData *fileEncryptAeskey = nil;
    NSData *fileData = nil;
    
    if ([needOpenMaterial isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)needOpenMaterial;
        //读取加密pdf文档
        NSString *fullPath = [AgendaFileDirPath stringByAppendingPathComponent:fileMeta.filePath];
        fileData = [NSData dataWithContentsOfFile:fullPath];
        //将本地文件数据根据cyberArk获取的密钥进行解密
//        fileEncryptAeskey = [CyberArkSecurity fileAeskeyWithFileIdentifier:fileMeta.materialIdentification];
        
    }
    
    
//    NSData *decodeData = [fileData AESDecryptWithKey:fileEncryptAeskey keyLength:AES128];
    CFDataRef dataRef = (__bridge_retained CFDataRef)(fileData);
    CGDataProviderRef dataProviderRef = CGDataProviderCreateWithCFData(dataRef);
    
    _pdfDocumentRef = CGPDFDocumentCreateWithProvider(dataProviderRef);
    
    CGDataProviderRelease(dataProviderRef);
    
}



#pragma mark - end


#pragma mark ----     私有接口      ----
#pragma mark -------------初始化相关方法--------------
/**
 *    @brief    初始化相关的数组或字典
 */
- (void)initAllArrayAndDictionary {
    _tagMutableArray = [[NSMutableArray alloc] init];
    _dataSaveInLocalDc = [[NSMutableDictionary alloc] init];
}


#pragma mark - 设置默认的画笔大小和颜色
- (void)setDefaultHandSizeAndColor {
    _selectedHandSize = DefaultSquiggleLineWidth;
    
    if(_selectedHandColor) {
        _selectedHandColor = nil;
    }
    
    _selectedHandColor = [[UIColor alloc] initWithRed:1.0 green:0.0 blue:0.0 alpha:0.5];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandSizeViewTag] viewWithTag:kMaxSizeButtonTag] setSelected:NO];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandSizeViewTag] viewWithTag:kMidSizeButtonTag] setSelected:NO];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandSizeViewTag] viewWithTag:kMinSizeButtonTag] setSelected:YES];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandColorViewTag] viewWithTag:kRedColorButtonTag] setSelected:YES];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandColorViewTag] viewWithTag:kGrayColorButtonTag] setSelected:NO];
    [(UIButton *)[(UIView *)[_remarkModelView viewWithTag:kHandColorViewTag] viewWithTag:kBlueColorButtonTag] setSelected:NO];
}


#pragma mark - 显示pdf前，清除一些内存
- (void)clearMemoryBeforeShowPDF {
    //清除_theScrollView上所有subviews
    __block NSMutableArray *needRemoveKeyArray = [[NSMutableArray alloc] init];
    [_contentViews enumerateKeysAndObjectsUsingBlock:
     ^(id key, id object, BOOL *stop)
     {
         [needRemoveKeyArray addObject:key];
         ReaderContentView *contentView = object;
         [contentView removeFromSuperview];
     }];
    
    [_contentViews removeObjectsForKeys:(NSArray *)needRemoveKeyArray];
    
    //清除缓存
    if (_curTextField) [_curTextField setText:@""];
    if (_curMaterial){
        _curMaterial = nil;
    }
    if (_imagePretendViewData) {
        _imagePretendViewData = nil;
    }
    if (_imageTouchHandData) {
        _imageTouchHandData = nil;
    }
    if (_currentViewMicroImage) {
        _currentViewMicroImage = nil;
    }
    if (_currentViewHandImage) {
        _currentViewHandImage = nil;
    }
    
    if (_pdfDocumentRef) {
        CGPDFDocumentRelease(_pdfDocumentRef);
        _pdfDocumentRef = nil;
    }
    
}

#pragma mark -------------控制顶部导航页面和底部辅助功能页面的相关方法--------------

#pragma mark -  动画隐藏阅读时的辅助工具栏
- (void)hideToolAndTabbar {
    self.navigationController.navigationBar.hidden = YES;
   
    [_readModelView setHidden:YES];
}

#pragma mark - 动画隐藏阅读时的辅助工具栏
- (void)hideToolbarAndTabbar {
    
    [self.navigationController.navigationBar setHidden:YES];
    
    self.theViewFrame = self.view.bounds;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(hideToolAndTabbar)];
    
    //只有横屏的时候才变化宽高
    //判断屏幕方向是竖着
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])){
        _theScrollView.frame = self.view.bounds;
    }else{
        _theScrollView.frame = self.theViewFrame;
    }
    
    [self.view setNeedsLayout];
    
    [self.navigationController.navigationBar setAlpha:0];
    [_readModelView setAlpha:0];
    [UIView commitAnimations];
}


#pragma mark -  动画显示阅读时的辅助工具栏

- (BOOL)showToolbarAndTabbar {
    if (!self.navigationController.navigationBar.hidden){
        return NO;
    }
    
    self.theViewFrame = CGRectMake(0, 80, kScreenWidth, kScreenHeight-80-120);
    
    [self.navigationController.navigationBar setHidden:NO];
    [_readModelView setHidden:NO];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    
    //只有横屏的时候才变化宽高
    //判断屏幕方向是竖着
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])){
        _theScrollView.frame = self.view.bounds;
    }else{
        _theScrollView.frame = self.theViewFrame;
    }
    
    [self.view setNeedsLayout];
    
    [self.navigationController.navigationBar setAlpha:1];
    [_readModelView setAlpha:1];
    [UIView commitAnimations];
    
    return YES;
}


#pragma mark -------------pdf阅读相关方法--------------


/**
 *    @brief    跳到指定页面
 *
 *    @param     numPage     pdf页码
 */
- (void)gotoPage:(int)numPage {
    if (numPage > 0 && numPage < (_totalPages + 1)) {
        [self showDocument:[NSNumber numberWithInt:numPage-1]];
    }
}

/**
 *    @brief    更新_theScrollView的contentSize
 */
- (void)updateScrollViewContentSize {

    NSInteger count = _totalPages;
    
    if (count > PAGING_VIEWS) count = PAGING_VIEWS; // Limit
    
    CGFloat contentHeight = _theScrollView.bounds.size.height;
    
    CGFloat contentWidth = (_theScrollView.bounds.size.width * count);
    
    _theScrollView.contentSize = CGSizeMake(contentWidth, contentHeight);
}

/**
 *    @brief    切换contentView时，更新_theScrollView的子View（contentView）
 */
- (void)updateScrollViewContentViews {

    [self updateScrollViewContentSize]; // Update the content size
    
    NSMutableIndexSet *pageSet = [NSMutableIndexSet indexSet]; // Page set
    
    [_contentViews enumerateKeysAndObjectsUsingBlock: // Enumerate content views
     ^(id key, id object, BOOL *stop)
     {
         ReaderContentView *contentView = object;
         [pageSet addIndex:contentView.tag - 1];
     }
     ];
    
    __block CGRect viewRect = CGRectZero;
    viewRect.size = _theScrollView.bounds.size;
    __block CGPoint contentOffset = CGPointZero;
    NSInteger page = _currentPage;
    
    [pageSet enumerateIndexesUsingBlock: // Enumerate page number set
     ^(NSUInteger number, BOOL *stop)
     {
         NSNumber *key = [NSNumber numberWithInteger:number]; // # key
         
         ReaderContentView *contentView = [_contentViews objectForKey:key];
         
         contentView.frame = viewRect;
         if (page == number) contentOffset = viewRect.origin;
         viewRect.origin.x += viewRect.size.width;
     }
     ];
    if (CGPointEqualToPoint(_theScrollView.contentOffset, contentOffset) == false)
    {
        _theScrollView.contentOffset = contentOffset; // Update content offset
    }
}

/**
 *    @brief    根据初始页码显示对应的pdf页数
 *
 *    @param     page     pdf页码
 */
- (void)showDocumentPage:(NSInteger)page {
    
    NSInteger minValue; NSInteger maxValue;
    NSInteger maxPage = _totalPages - 1;
    NSInteger minPage = 0;
    
    if (page != _currentPage){
        if ((page < minPage) || (page > maxPage)) return;
        
        if (maxPage < PAGING_VIEWS)
        {
            minValue = minPage;
            maxValue = maxPage;
        }
        else
        {
            minValue = (page - 1);
            maxValue = (page + 1);
            
            if (minValue < minPage)
            {minValue++; maxValue++;}
            else
                if (maxValue > maxPage)
                {minValue--; maxValue--;}
        }
        
        NSMutableDictionary *unusedViews = [_contentViews mutableCopy];
        
        CGRect viewRect = CGRectZero;
        viewRect.size = _theScrollView.bounds.size;
        
        for (NSInteger number = minValue; number <= maxValue; number++)
        {
            NSNumber *key = [NSNumber numberWithInteger:number]; // # key
            
            ReaderContentView *contentView = [_contentViews objectForKey:key];
            
            if (contentView == nil) // Create a brand new document content view
            {
                //显示标注
                [self displayHandOfCurrentViewWithPage:number];
                contentView = [[ReaderContentView alloc] initWithFrame:viewRect
                                                        pDFDocumentRef:_pdfDocumentRef
                                                               numPage:number
                                                         pdfMicroImage:_currentViewMicroImage.image
                                                          pdfHandImage:_currentViewHandImage.image];
                [_theScrollView addSubview:contentView];
                [_contentViews setObject:contentView forKey:key];
                
                [self.view bringSubviewToFront:self.navigationController.navigationBar];
                [self.view bringSubviewToFront:_readModelView];
                
                contentView.message = self;
               
                
            }
            else // Reposition the existing content view
            {
                
                contentView.frame = viewRect; [contentView zoomReset];
                
                [unusedViews removeObjectForKey:key];
            }
            viewRect.origin.x += viewRect.size.width;
        }
        
        [unusedViews enumerateKeysAndObjectsUsingBlock:
         ^(id key, id object, BOOL *stop)
         {
             [_contentViews removeObjectForKey:key];
             
             ReaderContentView *contentView = object;
             
             [contentView removeFromSuperview];
         }
         ];
        
        
        unusedViews = nil;
        
        CGFloat viewWidthX1 = viewRect.size.width;
        CGFloat viewWidthX2 = (viewWidthX1 * 2.0f);
        
        CGPoint contentOffset = CGPointZero;
        
        if ((maxPage + 1) >= PAGING_VIEWS)
        {
            if (page == maxPage)
                contentOffset.x = viewWidthX2;
            else
                if (page != minPage)
                    contentOffset.x = viewWidthX1;
        }
        else
            if ((page + 1) == (PAGING_VIEWS - 1))
                contentOffset.x = viewWidthX1;
        
        if (CGPointEqualToPoint(_theScrollView.contentOffset, contentOffset) == false)
        {
            _theScrollView.contentOffset = contentOffset;
        }
        
        self.currentPage = page;
    }
}

/**
 *    @brief    根据初始页码显示对应的pdf页数
 *
 *    @param     object     初始页码对象
 */
- (void)showDocument:(id)object {

    [self updateScrollViewContentSize]; // Set content size
    if (_pdfDocumentRef) {
        if (object) {
            [self showDocumentPage:[object intValue]];
            
        }else{
            [self showDocumentPage:_currentPage];
        }
    }
    _isVisible = YES;
}



#pragma mark ----------与批注相关的方法 -----------
/**
 *    @brief    将当前页的缩略图和批注内容作为图片数据保存，用来做标签视图，在我的批注页面只需要显示这个视图就可以（提高批注页面的显示效率）
 *
 *    @return    返回图片的二进制数据
 */
- (NSData *)getMicroimageDataOfPDFContent {
    UIView *tempView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 180.0, 260.0)];
    [tempView setBackgroundColor:[UIColor clearColor]];
    
    UIImageView *backView = [[UIImageView alloc] initWithImage:[_curReaderContentView getMicroimageDataOfPDFContent]];
    
    UIImageView *frontView = [[UIImageView alloc] initWithImage:[UIImage reSizeImage:[UIImage imageWithData:self.imageTouchHandData] toSize:tempView.bounds.size]];
    
    [tempView addSubview:backView];
    [tempView addSubview:frontView];
    
    UIGraphicsBeginImageContext(tempView.bounds.size);
    [tempView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
   
    return UIImagePNGRepresentation(viewImage);
}


#pragma mark - 显示指定页面的批注
- (void)displayHandOfCurrentViewWithPage:(int)page {
    if (_currentViewHandImage) {
        _currentViewHandImage = nil;
    }
    if (_currentViewMicroImage) {
        _currentViewMicroImage = nil;
    }
    
    for (Marker *marker in _tagMutableArray) {
        if (marker.page == page) {
            UIImage *handImage = [UIImage imageWithData:marker.touchHandData];
            _currentViewHandImage = [[UIImageView alloc] initWithImage:handImage];
            UIImage *microImage = [UIImage imageWithData:marker.pretendViewData];
            _currentViewMicroImage = [[UIImageView alloc] initWithImage:microImage];
        }
    }
}


#pragma mark -     离开当前页面时，如果有新增的笔迹，则将笔迹连同页面的内容进行保存（以图片的形式保存为二进制数据）
- (void)saveHandOfCurrentView {
    //保存在数组里，当按Home键，上一份，下一份时将数组内容保存到本地文件中
    if (self.imageTouchHandData) {
        //判断数组中是否已经存在当前页面的marker
        BOOL isOld = NO;
        int index = 0;
        for (Marker *marker in _tagMutableArray) {
            if (marker.page == _currentPage) {
                //已经存在
                isOld = YES;
                marker.touchHandData = self.imageTouchHandData;
                marker.pretendViewData = self.imagePretendViewData;
                [_tagMutableArray replaceObjectAtIndex:index withObject:marker];
                break;
            }
            index++;
        }
        if (!isOld) {
            //不存在，新添加的标签
            Marker *marker = [[Marker alloc] init];
            marker.page = _currentPage;
            NSDate *date = [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
            [marker setTagDate:[dateFormatter stringFromDate:date]];
          
            marker.touchHandData = self.imageTouchHandData;
            marker.pretendViewData = self.imagePretendViewData;
            
            [_tagMutableArray addObject:marker];
            
        }
    }
}


#pragma mark - 保存批注数据到本地
- (void)saveHandDataToLocal {
    if (self.imageTouchHandData) {
        
        NSString *remarkPath = nil;
        //判断文件类型
        if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
            
            HYRFileMeta *fileMate = (HYRFileMeta *)_curMaterial;
            remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:fileMate.materialid];
//            [DataBaseManager saveData:_tagMutableArray toFile:remarkPath];
            //更新数据库
            fileMate.remarkPath = fileMate.materialid;
            
//            [[DataBaseManager dataBaseManager] updateFromDatabaseWithFileMeta:fileMate];
            
        }
        
        
        
        
    }
}

/**
 *    @brief    显示保存数据的进度
 */
- (void)showSavingLoadingProgressView {
    _curDataLookoverModel = DataLookoverModelRead;
    [_readModelView setHidden:NO];
    [_remarkModelView setHidden:YES];
    [_dataLookoverModelButton setTitle:NSLocalizedString(@"Comment", nil) forState:UIControlStateNormal];
    [_dataLookoverModelButton setImage:[UIImage imageNamed:@"Com_comment"] forState:UIControlStateNormal];
    //显示返回按钮

    //如果当前笔迹有更新，则保存当前笔迹
    if (_curReaderContentView) {
        //获取更新的批注内容
        NSData *touchHandData = [_curReaderContentView.noteView saveHandImageData];
        
        //存在新的笔迹内容,则添加到内存（数组中）
        if (touchHandData) {
            //释放旧的笔迹
            if (self.imageTouchHandData) {
                _imageTouchHandData = nil;
            }
            
            self.imageTouchHandData = touchHandData;
            if (_currentViewHandImage) {
                _currentViewHandImage = nil;
            }
            _currentViewHandImage = [[UIImageView alloc] initWithImage:[UIImage imageWithData:self.imageTouchHandData]];
            //则去获取当前页面的缩略图(包含笔迹)
            self.imagePretendViewData = [self getMicroimageDataOfPDFContent];
            _currentViewMicroImage = [[UIImageView alloc] initWithImage:[UIImage imageWithData:self.imagePretendViewData]];
            
            //将笔迹内容保存到数组中
            [self saveHandOfCurrentView];
        }
        [_curReaderContentView hideNoteView:_currentViewHandImage.image];
        // 判断实际缩放
        _curReaderContentView.actualScale = _curReaderContentView.actualScale > 30 ? 1: _curReaderContentView.actualScale ;
        //
        //_selectedHandSize /= _curReaderContentView.actualScale;
        _curReaderContentView = nil;
        [_curReaderContentView setTheContainerViewBackgroundImage:_currentViewMicroImage.image];
        _theScrollView.scrollEnabled = YES;
    }
    
    //显示我的批注
    if ([_tagMutableArray count] > 0)
        _bookMarkButton.hidden = NO;
    
}


#pragma mark -------------动画相关方法--------------
/**
 *    @brief    UIView改变frame时的简单动画，
 *
 *    @param     subView     做动画的view
 *    @param     beginPoint_x     view开始的位置
 *    @param     endPoint_x     view结束时的位置
 */
- (void)animationWithSubView:(UIView *)subView BeginPoint_x:(CGFloat)beginPoint_x EndPoint_x:(CGFloat)endPoint_x {
    subView.frame = CGRectMake(beginPoint_x, subView.frame.origin.y, subView.frame.size.width, subView.frame.size.height);
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    subView.frame = CGRectMake(endPoint_x, subView.frame.origin.y, subView.frame.size.width, subView.frame.size.height);
    [UIView commitAnimations];
}

/**
 *    @brief    UIView在Y轴方向移动动画效果
 *
 *    @param     view     做动画的view
 *    @param     originY     view结束时的位置
 */
- (void)view:(UIView *)view playAnimationToOriginY:(CGFloat)originY {
    CGRect frame = view.frame;
    frame.origin.y = originY;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    [view setFrame:frame];
    [UIView commitAnimations];
}


#pragma mark ------------ 其他相关方法 --------------

/**
 *    @brief    添加键盘监听
 */
- (void)addKeyboardObserver {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideKeyboard:) name:UIKeyboardWillHideNotification object:nil];
}

/**
 *    @brief    移除键盘监听
 */
- (void)removeKeyboardObserver {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}


#pragma mark -------------事件响应方法--------------


#pragma mark - ---------------我的批注---------------
- (void)bookMarkBtnClick:(id)sender {
    //保存批注
    [self saveHandDataToLocal];
    //创建书签控制器
    BookMarkViewController *bookMarkViewController = [[BookMarkViewController alloc] init];
    
    bookMarkViewController.view.backgroundColor = [UIColor colorWithHexString:@"#bebebe" alpha:1.0];
    _isPopFromBookMarkView = YES;
    
    //
    if (_isPushFromBookMarkView) {
        [self.navigationController popViewControllerAnimated:YES];
        [bookMarkViewController showBookMarkWithFileMeta:_curMaterial];
        _isPushFromBookMarkView = NO;
    }else{
        //
        [self.navigationController pushViewController:bookMarkViewController animated:YES];
        [bookMarkViewController showBookMarkWithFileMeta:_curMaterial];
        [bookMarkViewController setIsPushFromPDFReadView:YES];
    }
}


#pragma mark - -------- 点击批注按钮 -----------
- (void)modelTypeBtnClick:(id)sender{
    
    //阅读、批注按钮事件
    if (_curDataLookoverModel == DataLookoverModelRead) {
        //
        [self begingComment];
    }
    else{
        
        [self saveComment:sender];
    }

}

#pragma mark - 点击变成编辑
- (void)begingComment {
    
    [_curTextField resignFirstResponder];//确保键盘消失
    
    [_readModelView setHidden:YES];
    [_remarkModelView setHidden:NO];

    //“返回”按钮  改变图片 文字变成“退出”
//    [self.cusNavigationController setReturnButtonTiltle:NSLocalizedString(@"Quit", nil) Withimg:[UIImage imageNamed:@"Com_exit"]];
    
    //切换批注按钮的模式
    _curDataLookoverModel = DataLookoverModelRemark;
    //批注的按钮变成 保存按钮   改变文字和图片
    [_dataLookoverModelButton setTitle:NSLocalizedString(@"Save", nil) forState:UIControlStateNormal];
    [_dataLookoverModelButton setImage:[UIImage imageNamed:@"Read_SaveComment"] forState:UIControlStateNormal];
    
    //遍历子视图
    [_contentViews enumerateKeysAndObjectsUsingBlock:
     ^(id key, id object, BOOL *stop)
     {
         ReaderContentView *contentView = object;
         
         if ((contentView.tag - 1) == _currentPage)
         {
             _curReaderContentView = contentView;
             *stop = YES;
         }
     }
     ];
    
    [self displayHandOfCurrentViewWithPage:_currentPage];
    
    //显示批注view
    if (_curReaderContentView) {
        [_curReaderContentView showNoteView:_currentViewHandImage.image];
    }
    
    [_curReaderContentView.noteView setHandLineWidth:_selectedHandSize];
    [_curReaderContentView.noteView setHandLineColor:_selectedHandColor];
    _theScrollView.scrollEnabled = NO;
    
}

#pragma mark - 保存批注  把相应按钮标题图标都改变
- (void)saveComment:(UIButton *)sender {
    //“退出”按钮  改变图片 文字变成 “返回”
//    [self.cusNavigationController setReturnButtonTiltle:NSLocalizedString(@"Return", nil) Withimg:[UIImage imageNamed:@"back"]];
    //有可能是直接退出
    if (sender) {
        [SVProgressHUD showWithStatus:[NSString stringWithFormat:@"%@...",NSLocalizedString(@"Saving", nil)]];
        [SVProgressHUD dismissWithDelay:2.0];
        [self performSelector:@selector(showSavingLoadingProgressView) withObject:nil afterDelay:0.1];
        
    }
}


#pragma mark - 上一页
- (void)preBtnClick:(id)sender{
    
    NSLog(@"点击了上一页...准备跳转..:%d",_currentPage);
    
    [self showDocumentPage:(_currentPage-1)];
    
    float progress = (float)(_currentPage+1) / _totalPages;
    //赋值给进度条
    _slider.value = progress;
    
#pragma mark - 将当前文件最后访问页面保存
    // - 判断文件类型
    if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)_curMaterial;
        [fileMeta setLastReadPage:_currentPage];
//        [[DataBaseManager dataBaseMan?ager] InsertTable:fileMeta];
    }
    
    
    
}


#pragma mark -  - 下一页

- (void)nextBtnClick:(id)sender{
    
    [self showDocumentPage:(_currentPage+1)];
    
    float progress = (float)(_currentPage+1) / _totalPages;
    //赋值给进度条
    _slider.value = progress;

#pragma mark - 将当前文件最后访问页面保存
    // - 判断文件类型
    if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)_curMaterial;
        [fileMeta setLastReadPage:_currentPage];
       // [[DataBaseManager dataBaseManager] InsertTable:fileMeta];
    }
    
    
    
}

#pragma mark - 批注模式下画笔大小、颜色等按钮事件
- (void)sizeBtnClick:(id)sender {
    UIButton *button = (UIButton *)sender;
    [button setSelected:YES];
    // 判断实际缩放 jay
    _curReaderContentView.actualScale = _curReaderContentView.actualScale > 30 ? 1: _curReaderContentView.actualScale ;
    //
    if (_curReaderContentView.noteView) {
        switch (button.tag) {
            case kMaxSizeButtonTag:
            {
                _selectedHandSize = DefaultSquiggleLineWidth * 4 * _curReaderContentView.actualScale;
                [_curReaderContentView.noteView setHandLineWidth:_selectedHandSize];
                [(UIButton *)[[button superview] viewWithTag:kMidSizeButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kMinSizeButtonTag] setSelected:NO];
            }
                break;
            case kMidSizeButtonTag:
            {
                _selectedHandSize = DefaultSquiggleLineWidth * 2.5 * _curReaderContentView.actualScale;
                [_curReaderContentView.noteView setHandLineWidth:_selectedHandSize];
                [(UIButton *)[[button superview] viewWithTag:kMaxSizeButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kMinSizeButtonTag] setSelected:NO];
            }
                break;
            case kMinSizeButtonTag:
            {
                _selectedHandSize = DefaultSquiggleLineWidth  * _curReaderContentView.actualScale;
                [_curReaderContentView.noteView setHandLineWidth:_selectedHandSize];
                [(UIButton *)[[button superview] viewWithTag:kMaxSizeButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kMidSizeButtonTag] setSelected:NO];
            }
                break;
            default:
                break;
        }
    }
}


#pragma mark - 批注模式下 选中颜色

- (void)colorBtnClick:(id)sender{
    UIButton *button = (UIButton *)sender;
    [button setSelected:YES];
    if (_curReaderContentView.noteView) {
        switch (button.tag) {
            case kRedColorButtonTag:
            {
                if(_selectedHandColor){
                    _selectedHandColor = nil;
                }
                _selectedHandColor = [[UIColor alloc] initWithRed:1.0 green:0.0 blue:0.0 alpha:0.5];
                [(UIButton *)[[button superview] viewWithTag:kGrayColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlueColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlackColorButtonTag] setSelected:NO];
            }
                break;
            case kGrayColorButtonTag:
            {
                if(_selectedHandColor){
                    _selectedHandColor = nil;
                }
                
                _selectedHandColor = [UIColor colorWithHexString:@"#858585" alpha:0.5];
                [(UIButton *)[[button superview] viewWithTag:kRedColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlueColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlackColorButtonTag] setSelected:NO];
            }
                break;
            case kBlueColorButtonTag:
            {
                if(_selectedHandColor) {
                    _selectedHandColor = nil;
                }
                
                _selectedHandColor = [[UIColor alloc] initWithRed:0.0 green:0.0 blue:1.0 alpha:0.5];
                [(UIButton *)[[button superview] viewWithTag:kRedColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kGrayColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlackColorButtonTag] setSelected:NO];
            }
                break;
            case kBlackColorButtonTag:
            {
                if(_selectedHandColor) {
                    _selectedHandColor = nil;
                }
                
                _selectedHandColor = [[UIColor alloc] initWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
                [(UIButton *)[[button superview] viewWithTag:kRedColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kGrayColorButtonTag] setSelected:NO];
                [(UIButton *)[[button superview] viewWithTag:kBlueColorButtonTag] setSelected:NO];
            }
                break;
            default:
                break;
        }
        [_curReaderContentView.noteView setHandLineColor:_selectedHandColor];
    }
}

#pragma mark - 撤销上一步画的批注
- (void)withDrawBtnClick:(id)sender{
    if (_curReaderContentView.noteView) {
        [_curReaderContentView.noteView eraserHand:YES];
    }
}

#pragma mark - 显示键盘
- (void)showKeyboard:(NSNotification *)notification {
    //
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
        [self view:_readModelView playAnimationToOriginY:PDFREADVIEW_DESKTOP_LANDSCAPE_Y - 350.0];
    else
        [self view:_readModelView playAnimationToOriginY:PDFREADVIEW_DESKTOP_PROTRAIT_Y - 262.0];
}

#pragma mark -  隐藏键盘
- (void)hideKeyboard:(NSNotification *)notification {
    //
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
        [self view:_readModelView playAnimationToOriginY:PDFREADVIEW_DESKTOP_LANDSCAPE_Y];
    else
        [self view:_readModelView playAnimationToOriginY:PDFREADVIEW_DESKTOP_PROTRAIT_Y];
}

#pragma mark - 双击隐藏/显示 导航栏和底部栏
- (void)handleDoubleTap:(UITapGestureRecognizer *)recognizer{
    
    if (_pdfDocumentRef && (_curDataLookoverModel != DataLookoverModelRemark)) {
        
        //self.theViewFrame = self.view.bounds;
        
        if (1 == recognizer.numberOfTapsRequired) {
            //单击
            NSLog(@"用户点击了");
            if (![self showToolbarAndTabbar]) {
                [self hideToolbarAndTabbar];
            }
        }else{
            //双击
            if (![self showToolbarAndTabbar]) {
                [self hideToolbarAndTabbar];
            }
        }
        
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -
#pragma mark =======    代理实现     =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark ------------ textField delegate ---------------
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self gotoPage:[textField.text intValue]];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet];
    NSString *filetered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
    BOOL result = [string isEqualToString:filetered];
    return result;
}


#pragma mark ------------- UIScrollViewDelegate -------------------
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [_dataLookoverModelButton setUserInteractionEnabled:NO];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
#ifdef DEBUGX
    NSLog(@"%s", __FUNCTION__);
#endif
    
    __block NSInteger page = 0;
    
    CGFloat contentOffsetX = scrollView.contentOffset.x;
    
    [_contentViews enumerateKeysAndObjectsUsingBlock: // Enumerate content views
     ^(id key, id object, BOOL *stop)
     {
         ReaderContentView *contentView = object;
         
         if(contentView.frame.origin.x == contentOffsetX){
             page = contentView.tag - 1; *stop = YES;
         }
     }];
    
    [self showDocumentPage:page]; // Show the page
 
    [_dataLookoverModelButton setUserInteractionEnabled:YES];
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
#ifdef DEBUGX
    NSLog(@"%s", __FUNCTION__);
#endif
    
    [self showDocumentPage:_theScrollView.tag]; // Show page
    
    _theScrollView.tag = 0; // Clear page number tag
}


#pragma mark ---------------- UIGestureRecognizerDelegate ----------------
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)recognizer shouldReceiveTouch:(UITouch *)touch{
#ifdef DEBUGX
    NSLog(@"%s", __FUNCTION__);
#endif
    
    // 点击tableViewCell不执行Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"HYRSlider"]) {
        return NO;
    }
    
    if ([touch.view isKindOfClass:[UIScrollView class]]){
        return YES;
    }
    
    return NO;
}

#pragma mark -------------- ReaderContentViewDelegate ---------------------
- (void)contentView:(ReaderContentView *)contentView touchesBegan:(NSSet *)touches{
#ifdef DEBUGX
    NSLog(@"%s", __FUNCTION__);
#endif
    if (touches.count == 1) // Single touches only
    {
        UITouch *touch = [touches anyObject]; // Touch info
        
        NSLog(@"用户点击了：%ld次", touch.tapCount);
        
        
        CGPoint point = [touch locationInView:self.view]; // Touch location
        
        CGRect areaRect = CGRectInset(self.view.bounds, TAP_AREA_SIZE, TAP_AREA_SIZE);
        
        if (CGRectContainsPoint(areaRect, point) == false){
            return;
        }
        
        
        
    }
}



#pragma mark --------程序扩展     --------
- (void)relayoutForInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation withDuration:(NSTimeInterval)duration {
    //判断屏幕方向是竖着
    if (UIInterfaceOrientationIsPortrait(interfaceOrientation)){
        [self relayoutElementsForPortrait];
    }else{
        [self relayoutElementsForLandscape];
    }
}

#pragma mark --------系统自带  --------


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    _isMemoryWarning = YES;
    if (_currentViewHandImage) _currentViewHandImage = nil;
    if (_currentViewMicroImage) _currentViewMicroImage = nil;
    if (_imageTouchHandData) _imageTouchHandData = nil;
    if (_imagePretendViewData) _imagePretendViewData = nil;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (_curTextField) [_curTextField resignFirstResponder];
    
    //当前页面改变时，页码数也要随着改变
    [self addObserver:self forKeyPath:@"currentPage" options:NSKeyValueObservingOptionNew context:nil];
    
    if (_isMemoryWarning) {
        _isMemoryWarning = NO;
    }
    
    
    if (_isPushFromBookMarkView) {
      
        
    }
    
    //如果是在我的批注界面返回回来的
    if (_isPopFromBookMarkView) {
        //获取存储在本地的标签数据源
        [self setTagMutableArrayDataSource:_curMaterial];
        [self showPDFWithFileMeta:_curMaterial andPage:_currentPage];
        
        _isPopFromBookMarkView = NO;
    }
    
    // 通过状态栏电池图标来判断屏幕方向
    if (UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation)) {
        [self relayoutElementsForPortrait];
    }else{
        [self relayoutElementsForLandscape];
    }
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)viewWillLayoutSubviews {

    //判断屏幕方向是竖着
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])){
        _theScrollView.frame = self.view.bounds;
    }else{
       
        if (self.navigationController.navigationBar.hidden || self.readModelView.hidden) {
            _theScrollView.frame = self.view.bounds;
        }else{
            self.theViewFrame = CGRectMake(0, 80, kScreenWidth, kScreenHeight-80-120);
            _theScrollView.frame = self.theViewFrame;
        }
    }

    [self updateScrollViewContentViews];
}

//save curData
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
   
    _lastAppearSize = self.view.bounds.size; // Track view size
    
#pragma mark - 将当前文件最后访问页面保存
    // - 判断文件类型
    if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)_curMaterial;
        [fileMeta setLastReadPage:_currentPage];
        //[[DataBaseManager dataBaseManager] updateTableDataModel:fileMeta];
    }
    
    
    
    //销毁当前文件
    //_curMaterial = nil;
    //不能再这里销毁，万一是跳转到下一个界面(我的标注)这个当前文件销毁了的话，那就再次进入我的标注的时候传入的就是空对象了

    //移除KVO
    [self removeObserver:self forKeyPath:@"currentPage"];
    [self removeKeyboardObserver];
}





- (void)viewDidLoad{
    [super viewDidLoad];
    AppDelegate* appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    //appDelegate.allowRotation = 0;
    
    [UIDevice switchOrientation:UIInterfaceOrientationUnknown];
    
    //设定批注按钮的 默认阅读模式
    _curDataLookoverModel = DataLookoverModelRead;
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#A09D9A" alpha:1.0];
    //当前页面改变时，页码数也要随着改变
    [self addObserver:self forKeyPath:@"currentPage" options:NSKeyValueObservingOptionNew context:nil];
    
    [self loadScrollView];
    [self addKeyboardObserver];
    
    //设置批注的默认笔画大小和颜色
    [self setDefaultHandSizeAndColor];
    
    [self addNavgationButton];
    
    
    //阅读模式的底部栏
    [self loadReadModeltopView];
    //标注模式的底部栏
    [self loadRemarkModelView];
    
    
    //给view添加双击的手势
    UITapGestureRecognizer *doubleTapOne = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTap:)];
    doubleTapOne.numberOfTouchesRequired = 1;
    doubleTapOne.numberOfTapsRequired = 2;
    doubleTapOne.delegate = self;
    
    [self.view addGestureRecognizer:doubleTapOne];
    
    UITapGestureRecognizer *tapOne = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTap:)];
    tapOne.numberOfTouchesRequired = 1; //1个手指
    tapOne.numberOfTapsRequired = 1;  //单击
    tapOne.delegate = self;
    
    [self.view addGestureRecognizer:tapOne];
    
    
   
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString:@"currentPage"]) {
        //当前页面改变时，页码数也要随着改变
        _curTextField.text = [NSString stringWithFormat:@"%i",_currentPage + 1];
         //
        [(UILabel *)[_readModelView viewWithTag:kPageLabelTag] setText:[NSString stringWithFormat:@"/   %i",_totalPages]];
        //
        float progress = (float)(_currentPage+1) / _totalPages;
        //赋值给进度条
        _slider.value = progress;
        
        if ([_curTextField isFirstResponder]) [_curTextField resignFirstResponder];
        
    }
}

- (void)saveHandDateWhenapplicationDidEnterBackground{
    //保存当前页的笔迹内容
    if (_curDataLookoverModel == DataLookoverModelRemark) {
        if (_noteView) {
            NSData *touchData = [_noteView saveHandImageData];
            
            if (touchData) {//做了批注，才会去保存批注内容
                if (self.imageTouchHandData){
                    _imageTouchHandData = nil;
                }
                
                self.imageTouchHandData = touchData;
                
                if (self.imagePretendViewData){
                    _imagePretendViewData = nil;
                }
                    
                //获取当前页面的缩略图
                self.imagePretendViewData = [self getMicroimageDataOfPDFContent];
                [self saveHandOfCurrentView];
            }
        }
    }
    
    // - 判断文件类型
    if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)_curMaterial;
        [fileMeta setLastReadPage:_currentPage];
        //[[DataBaseManager dataBaseManager] InsertTable:fileMeta];
    }
    
    
  
    [self saveHandDataToLocal];
}

                                           

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    
    if (_isVisible == NO) return; // iOS present modal bodge
}


//当屏幕出现旋转开始并在动画发生之前自动调用此方法 重新设置控件的大小与位置
- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    [self relayoutForInterfaceOrientation:toInterfaceOrientation withDuration:duration];
    
    if (_isVisible == NO) return;
    [self updateScrollViewContentViews]; //旋转时需要重新绘制pdf页面
    _lastAppearSize = CGSizeZero;
}


//ios6.0后
- (BOOL)shouldAutorotate
{
    
    if (_curDataLookoverModel == DataLookoverModelRemark) {
        
        //设定在批注模式下，不允许旋转页面
        UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
        if (UIInterfaceOrientationIsPortrait(interfaceOrientation)) {
            
            return UIInterfaceOrientationIsLandscape(interfaceOrientation);
            
        }else{
            return UIInterfaceOrientationIsPortrait(interfaceOrientation);
        }
        
    }
    
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortraitUpsideDown;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return [[UIApplication sharedApplication] statusBarOrientation];
}

-(void)dealloc{
    NSLog(@"-----%s----%@",__FUNCTION__,[HYRPDFReaderViewController class]);
    
    [self removeObserver:self forKeyPath:@"currentPage"];
    [self removeKeyboardObserver];
    
}


@end
