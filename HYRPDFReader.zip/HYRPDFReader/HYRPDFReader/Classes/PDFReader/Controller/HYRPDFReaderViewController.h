//
//  HYRPDFReaderViewController.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "DataAccessSupport.h"
#import "ReaderContentView.h"
#import "NoteView.h"
#import "Marker.h"
#import "HYRFileMeta.h"               //普通会议文件
//#import "NoticeAttachmentMate.h"   //通知文件
//#import "GenericFileMeta.h"        //日常文件
//#import "HistoryFileMeta.h"        //历史文件
//#import "AgendaMeta.h"
#import "HYRMarkView.h"


/**
 *    @brief    pdf查看模式
 */
typedef enum{
    DataLookoverModelRead, /**< 阅读 */
    DataLookoverModelRemark  /**< 批注 */
}DataLookoverModel;



/**
 *    @brief    PDF阅读界面控制器，提供pdf阅读/批注，左右滑动翻页，指定页码跳转，上一份/下一份文档切换，文档放大/缩小，批注颜色/字体大小选择，撤销上一次批注笔迹等功能，以及提供了返回上级界面查看批注缩略图的入口
 */
@interface HYRPDFReaderViewController : UIViewController <UITextFieldDelegate,UIScrollViewDelegate,UIGestureRecognizerDelegate,ReaderContentViewDelegate>

//标示当前选择的页码
@property(nonatomic,assign) int currentPage;
 //总共页数
@property(nonatomic,assign) int totalPages;
//当前选择的章节
@property(nonatomic,assign) int currentChapter;
//记录当前选中资料的索引值
@property(nonatomic,assign) int curNumberAgenDaData;

//当前view是不是由我的批注界面push过来的
@property(nonatomic,assign)BOOL isPushFromBookMarkView;

//当前view是不是由我的批注界面pop回来的
@property(nonatomic,assign)BOOL isPopFromBookMarkView;

//标志是否从我的批注页面跳转到当前页面的
@property(nonatomic,assign)BOOL preViewIsSelectedBookMarkView;
 //pdf内容页面是否显示
@property(nonatomic,assign) BOOL isVisible;
@property(nonatomic,assign) BOOL isMemoryWarning;
//翻向前一份资料的最后一页
@property(nonatomic,assign) BOOL isFlipToLastPageForPreData;

//pdf文件的操作句柄
@property(nonatomic,assign) CGPDFDocumentRef pdfDocumentRef;
//pdf内容view缩放后的显示区域
@property(nonatomic,assign) CGSize lastAppearSize;
 //当前选中的画笔大小;
@property(nonatomic,assign) CGFloat selectedHandSize;


//存储当前页面笔迹图片的二进制数据（在离开此页面时，若进行了批注，则此变量一定有值）
@property(nonatomic,strong) NSData *imageTouchHandData;
//存储当前页面截图的二进制数据，用来制作标签
@property(nonatomic,strong) NSData *imagePretendViewData;
//当前先中的画笔颜色
@property(nonatomic,strong) UIColor *selectedHandColor;
// 所有pdf内容view的一个容器，用来控制pdf内容view的切换
@property(nonatomic,strong) UIScrollView *theScrollView;
//存储在缓存中的用于显示pdf内容的View
@property(nonatomic,strong) NSMutableDictionary *contentViews;
//当前页面笔迹图片
@property(nonatomic,strong) UIImageView *currentViewHandImage;
//当前页面的缩略图
@property(nonatomic,strong) UIImageView *currentViewMicroImage;
//当前显示pdf内容的view
@property(nonatomic,strong) ReaderContentView *curReaderContentView;
//当由标签模式转为阅读模式时，需要存储当前页面的笔迹内容
@property(nonatomic,strong) NoteView *noteView;
//阅读时使用的辅助功能View
@property(nonatomic,strong) UIView *readModelView;
 //readModelView的subView，可以输入要跳转的页面
@property(nonatomic,strong) UIView *pageGotoView;
//批注时使用的辅助功能View
@property(nonatomic,strong) HYRMarkView *remarkModelView;
//资料查看模式按钮（阅读和批注两种模式）
@property(nonatomic,strong) UIButton *dataLookoverModelButton;
//我的批注
@property(nonatomic,strong) UIButton *bookMarkButton;
//记录当前是哪种资料查看模式
@property(nonatomic,assign) DataLookoverModel curDataLookoverModel;
//记录最后响应事件的输入框
@property(nonatomic,strong) UITextField *curTextField;
//如果当前会议资料是会议资料，则表示资料所属于的会议议程
@property(nonatomic,strong) NSArray *agendas;

//当前显示的资料
@property(nonatomic,strong) id curMaterial;
//当前显示的资料
@property(nonatomic,strong) HYRFileMeta *curFileMeta;
//当前通知的资料
//@property(nonatomic,strong) NoticeAttachmentMate *curNoticeMeta;
////当前日常文件的资料
//@property(nonatomic,strong) GenericFileMeta *curGenericMeta;
////当前历史文件的资料
//@property(nonatomic,strong) HistoryFileMeta *curHistoryMeta;


//存储标签数据,在工程里所有对tag的修改都会反映在这个数组里面，只在这个类里创建一次，其他地方都是使用它的引用
@property(nonatomic,strong) NSMutableArray *tagMutableArray;
//选中议程的所有的资料
@property(nonatomic,strong) NSArray *agenDaAllDataSource;
//存储选中议程所有资料中下载成功资料的在_agenDaAllDataSource的索引值
@property(nonatomic,strong) NSMutableDictionary *dataSaveInLocalDc;

- (void)saveHandDateWhenapplicationDidEnterBackground;
/**
 展示指定的pdf阅读资料

 @param meta 需要显示的资料
 @param page 显示的页数
 */
- (void)showPDFWithFileMeta:(id)meta andPage:(int)page;

- (void)showPDFWithFileMetaWithFilePath:(NSString *)filePath andPage:(int)page;

@end
