//
//  ReaderContentPage.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import "ReaderContentPage.h"
#import "ReaderContentTile.h"

@implementation ReaderContentPage

//#pragma mark Properties

//@synthesize ;

#pragma mark ReaderContentPage class methods

/**
 *	@brief	获取画布类型
 *
 *	@return	画布类型
 */
+ (Class)layerClass
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	return [ReaderContentTile class];
}


#pragma mark ReaderContentPage instance methods

- (id)initWithFrame:(CGRect)frame
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	id view = nil; 

	if (CGRectIsEmpty(frame) == false)
	{
		if ((self = [super initWithFrame:frame]))
		{
			self.autoresizesSubviews = NO;
			self.userInteractionEnabled = NO;
			self.clearsContextBeforeDrawing = NO;
			self.contentMode = UIViewContentModeRedraw;
			self.autoresizingMask = UIViewAutoresizingNone;
			self.backgroundColor = [UIColor clearColor];

			view = self; // Return self
		}
	}
//    else // Handle invalid frame size
//    {
////        [self release];
//    }

	return view;
}

/**
 *	@brief	根据pdf文件引用和页码初始化对象
 *
 *	@param 	pdfDocumentRef 	pdf文档引用
 *	@param 	page 	指定页码
 *
 *	@return	初始化的对象
 */
- (id)initWithPDFDocumentRef:(CGPDFDocumentRef)pdfDocumentRef numPage:(NSUInteger)page
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	CGRect viewRect = CGRectZero; // View rect

	if (pdfDocumentRef) // Check for non-nil file URL
	{
		_PDFDocRef = CGPDFDocumentRetain(pdfDocumentRef);

		if (_PDFDocRef != NULL) // Check for non-NULL CGPDFDocumentRef
		{
			if (page < 1) page = 0; // Check the lower page bounds

			NSInteger pages = CGPDFDocumentGetNumberOfPages(_PDFDocRef);

			if (page > pages) page = pages - 1; // Check the upper page bounds

			_PDFPageRef = CGPDFDocumentGetPage(_PDFDocRef, page + 1); // Get page

			if (_PDFPageRef != NULL) // Check for non-NULL CGPDFPageRef
			{
				CGPDFPageRetain(_PDFPageRef); // Retain the PDF page

				CGRect cropBoxRect = CGPDFPageGetBoxRect(_PDFPageRef, kCGPDFCropBox);
				CGRect mediaBoxRect = CGPDFPageGetBoxRect(_PDFPageRef, kCGPDFMediaBox);
				CGRect effectiveRect = CGRectIntersection(cropBoxRect, mediaBoxRect);

				_pageAngle = CGPDFPageGetRotationAngle(_PDFPageRef); // Angle

				switch (_pageAngle) // Page rotation angle (in degrees)
				{
					default: // Default case
					case 0: case 180: // 0 and 180 degrees
					{
						_pageSize.width = effectiveRect.size.width;
						_pageSize.height = effectiveRect.size.height;
						break;
					}

					case 90: case 270: // 90 and 270 degrees
					{
						_pageSize.height = effectiveRect.size.width;
						_pageSize.width = effectiveRect.size.height;
						break;
					}
				}

				NSInteger page_w = _pageSize.width; // Integer width
				NSInteger page_h = _pageSize.height; // Integer height

				if (page_w % 2) page_w--; if (page_h % 2) page_h--; // Even

				viewRect.size = CGSizeMake(page_w, page_h); // View size
			}
			else // Error out with a diagnostic
			{
				CGPDFDocumentRelease(_PDFDocRef), _PDFDocRef = NULL;

				NSAssert(NO, @"CGPDFPageRef == NULL");
			}
		}
		else // Error out with a diagnostic
		{
			NSAssert(NO, @"CGPDFDocumentRef == NULL");
		}
	}
	else // Error out with a diagnostic
	{
		NSAssert(NO, @"fileURL == nil");
	}
	id view = [self initWithFrame:viewRect]; // UIView setup

	return view;
}

#pragma mark CATiledLayer delegate methods

/**
 *	@brief	在上下文中绘制文件的分块对象
 *
 *	@param 	layer 	文件页的分块对象
 *	@param 	context 	设备上下文
 */
- (void)drawLayer:(CATiledLayer *)layer inContext:(CGContextRef)context
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	CGPDFPageRef drawPDFPageRef = NULL;

	CGPDFDocumentRef drawPDFDocRef = NULL;

	@synchronized(self) // Block any other threads
	{
		drawPDFDocRef = CGPDFDocumentRetain(_PDFDocRef);

		drawPDFPageRef = CGPDFPageRetain(_PDFPageRef);
	}

	CGContextSetRGBFillColor(context, 1.0f, 1.0f, 1.0f, 1.0f); // White

	CGContextFillRect(context, CGContextGetClipBoundingBox(context)); // Fill

	if (drawPDFPageRef != NULL) // Go ahead and render the PDF page into the context
	{
		CGContextTranslateCTM(context, 0.0f, self.bounds.size.height); CGContextScaleCTM(context, 1.0f, -1.0f);
    
		CGContextConcatCTM(context, CGPDFPageGetDrawingTransform(drawPDFPageRef, kCGPDFCropBox, self.bounds, 0, true));

        CGContextSetInterpolationQuality(context, kCGInterpolationHigh);
  
		CGContextSetRenderingIntent(context, kCGRenderingIntentDefault); 

		CGContextDrawPDFPage(context, drawPDFPageRef); // Render the PDF page into the context
	}
  // Cleanup
	CGPDFPageRelease(drawPDFPageRef); 
  drawPDFPageRef = NULL;
  CGPDFDocumentRelease(drawPDFDocRef); 
  drawPDFDocRef = NULL;
}

@end

