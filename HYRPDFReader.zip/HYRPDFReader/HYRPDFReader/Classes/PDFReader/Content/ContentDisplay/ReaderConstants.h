//
//  ReaderConstants.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define READER_BOOKMARKS TRUE
#define READER_ENABLE_MAIL TRUE
#define READER_ENABLE_PRINT TRUE
#define READER_ENABLE_THUMBS TRUE
#define READER_DISABLE_IDLE FALSE
#define READER_SHOW_SHADOWS TRUE
#define READER_STANDALONE FALSE

