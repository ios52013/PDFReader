//
//  ReaderContentPage.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *	@brief	阅读器页面显示类，显示当前指定页内容
 */
@interface ReaderContentPage : UIView {
@private // Instance variables
	CGPDFDocumentRef _PDFDocRef;      // 当前pdf文档的引用
	CGPDFPageRef _PDFPageRef;             // 指定pdf页的引用
	NSInteger _pageAngle;                     // 文档页相对原始位置的翻转角度
	CGSize _pageSize;                             // 文件页的尺寸
}

/**
 *	@brief	根据pdf文件引用和页码初始化对象
 *
 *	@param 	pdfDocumentRef 	pdf文档引用
 *	@param 	page 	指定页码
 *
 *	@return	初始化的对象
 */
- (id)initWithPDFDocumentRef:(CGPDFDocumentRef)pdfDocumentRef numPage:(NSUInteger)page;
@end

