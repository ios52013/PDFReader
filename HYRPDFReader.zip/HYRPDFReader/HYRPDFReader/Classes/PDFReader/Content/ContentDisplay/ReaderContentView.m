//
//  ReaderContentView.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import "ReaderConstants.h"
#import "ReaderContentView.h"
#import "ReaderContentPage.h"
#import "NoteView.h"
#import "UIImage+HYRComponent.h"

#import <QuartzCore/QuartzCore.h>

@implementation ReaderContentView

#pragma mark Constants

#define ZOOM_LEVELS 3
#define ZOOM_AMOUNT 0.5f

#if (READER_SHOW_SHADOWS == TRUE)
	#define CONTENT_INSET 4.0f
#else
	#define CONTENT_INSET 2.0f
#endif 

#define PAGE_THUMB_LARGE 240
#define PAGE_THUMB_SMALL 144

#pragma mark Properties

@synthesize noteView;
@synthesize actualScale;
@synthesize message;

#pragma mark ReaderContentView functions

/**
 *	@brief	内联函数，按照适当方式取舍目标大小和原始大小
 *
 *	@param 	target 	目标尺寸
 *	@param 	source 	原始尺寸
 *
 *	@return	适当的尺寸值
 */
static inline CGFloat ZoomScaleThatFits(CGSize target, CGSize source)

{
	CGFloat w_scale = (target.width / source.width);
	CGFloat h_scale = (target.height / source.height);

	return ((w_scale < h_scale) ? w_scale : h_scale);
}

#pragma mark ReaderContentView instance methods

/**
 *	@brief	更新缩放大小
 */
- (void)updateMinimumMaximumZoom
{
	CGRect targetRect = CGRectInset(self.bounds, CONTENT_INSET, CONTENT_INSET);

	CGFloat zoomScale = ZoomScaleThatFits(targetRect.size, theContentView.bounds.size);
  
	self.minimumZoomScale = zoomScale; // Set the minimum and maximum zoom scales

	self.maximumZoomScale = (zoomScale * ZOOM_LEVELS); // Number of zoom levels
  
  if (curMaxZoomScale != self.maximumZoomScale) {
    actualScale = self.maximumZoomScale/curMaxZoomScale;
  }
  curMaxZoomScale = self.maximumZoomScale;
}

/**
 *	@brief	根据尺寸位置，pdf文档引用，选择页码，缩略图和批注笔迹初始化阅读内容显示界面
 *
 *	@param 	frame 	尺寸位置
 *	@param 	pdfDocumentRef 	pdf文件的引用
 *	@param 	page 	页码
 *	@param 	microImage 	页码的缩略图
 *	@param 	handImage 	批注笔迹
 *
 *	@return	阅读内容显示界面
 */
- (id)initWithFrame:(CGRect)frame
     pDFDocumentRef:(CGPDFDocumentRef)pdfDocumentRef
            numPage:(NSUInteger)page
      pdfMicroImage:(UIImage *)microImage
       pdfHandImage:(UIImage *)handImage
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	if ((self = [super initWithFrame:frame]))
	{
		self.scrollsToTop = NO;
		self.delaysContentTouches = NO;
		self.showsVerticalScrollIndicator = NO;
		self.showsHorizontalScrollIndicator = NO;
//		self.contentMode = UIViewContentModeRedraw;
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.backgroundColor = [UIColor clearColor];
		self.userInteractionEnabled = YES;
		self.autoresizesSubviews = NO;
		self.bouncesZoom = NO;
		self.delegate = self;

		theContentView = [[ReaderContentPage alloc] initWithPDFDocumentRef:pdfDocumentRef numPage:page];

		if (theContentView != nil) // Must have a valid and initialized content view
		{
			theContainerView = [[UIView alloc] initWithFrame:theContentView.bounds];

			theContainerView.autoresizesSubviews = NO;
			theContainerView.userInteractionEnabled = NO;
//			theContainerView.contentMode = UIViewContentModeRedraw;
			theContainerView.autoresizingMask = UIViewAutoresizingNone;
			theContainerView.backgroundColor = [UIColor whiteColor];

#if (READER_SHOW_SHADOWS == TRUE) // Option

			theContainerView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
			theContainerView.layer.shadowRadius = 4.0f; theContainerView.layer.shadowOpacity = 0.8f;
			theContainerView.layer.shadowPath = [UIBezierPath bezierPathWithRect:theContainerView.bounds].CGPath;

#endif // end of READER_SHOW_SHADOWS Option

			self.contentSize = theContentView.bounds.size; // Content size same as view size
			self.contentOffset = CGPointMake((0.0f - CONTENT_INSET), (0.0f - CONTENT_INSET)); // Offset
			self.contentInset = UIEdgeInsetsMake(CONTENT_INSET, CONTENT_INSET, CONTENT_INSET, CONTENT_INSET);

      containerViewBackgroundView = [[UIImageView alloc] initWithImage:microImage];
      [containerViewBackgroundView setFrame:theContainerView.bounds];
      [theContainerView addSubview:containerViewBackgroundView];
      
			[theContainerView addSubview:theContentView]; // Add the content view to the container view
      
      handImageView = [[UIImageView alloc] initWithImage:handImage];
      [handImageView setFrame:theContainerView.bounds];
      
			[theContainerView addSubview:handImageView]; 
      
      [self addSubview:theContainerView];

			[self updateMinimumMaximumZoom]; // Update the minimum and maximum zoom scales

			self.zoomScale = self.minimumZoomScale; // Set zoom to fit page content
		}

		[self addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew context:NULL];
    
        actualScale = 1.0;
		self.tag = page + 1; // Tag the view with the page number
	}

	return self;
}


/**
 *	@brief	监听到视图大小位置变化时改变缩放比例
 *
 *	@param 	keyPath 	改变的属性
 *	@param 	object 	改变属性的对象
 *	@param 	change 	存放改变后值的字典
 *	@param 	context 	上下文参数
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	if ((object == self) && [keyPath isEqualToString:@"frame"])
	{
		CGFloat oldMinimumZoomScale = self.minimumZoomScale;

		[self updateMinimumMaximumZoom]; // Update zoom scale limits

		if (self.zoomScale == oldMinimumZoomScale) // Old minimum
		{
			self.zoomScale = self.minimumZoomScale;
		}
		else // Check against minimum zoom scale
		{
			if (self.zoomScale < self.minimumZoomScale)
			{
				self.zoomScale = self.minimumZoomScale;
			}
			else // Check against maximum zoom scale
			{
				if (self.zoomScale > self.maximumZoomScale)
				{
					self.zoomScale = self.maximumZoomScale;
				}
			}
		}
	}
}

/**
 *	@brief	重新布局子视图位置
 */
- (void)layoutSubviews
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	[super layoutSubviews];
	CGSize boundsSize = self.bounds.size;
	CGRect viewFrame = theContainerView.frame;

	if (viewFrame.size.width < boundsSize.width)
		viewFrame.origin.x = (((boundsSize.width - viewFrame.size.width) / 2.0f) + self.contentOffset.x);
	else
		viewFrame.origin.x = 0.0f;

	if (viewFrame.size.height < boundsSize.height)
		viewFrame.origin.y = (((boundsSize.height - viewFrame.size.height) / 2.0f) + self.contentOffset.y);
	else
		viewFrame.origin.y = 0.0f;

	theContainerView.frame = viewFrame;
  if (noteView) noteView.frame = viewFrame;
}

/**
 *	@brief	放大，如果当前缩放比例小于最大缩放比例，则判断放大时候的比例如果大于了最大比例，则缩小到最小比例
 */
- (void)zoomIncrement
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	CGFloat zoomScale = self.zoomScale;
	if (zoomScale <= self.maximumZoomScale)
	{
		zoomScale += ZOOM_AMOUNT; // +=
		if (zoomScale > self.maximumZoomScale)
		{
			zoomScale = self.minimumZoomScale;
		}
	}
	if (zoomScale != self.zoomScale) // Do zoom
	{
		[self setZoomScale:zoomScale animated:YES];
	}
}


/**
 *	@brief	缩小，如果当前缩放比例大于最小缩放比例，则判断缩小时候的比例如果小于了最小比例，则放大到最大比例
 */
- (void)zoomDecrement
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	CGFloat zoomScale = self.zoomScale;
	if (zoomScale >= self.minimumZoomScale)
	{
		zoomScale -= ZOOM_AMOUNT; // -=
		if (zoomScale < self.minimumZoomScale)
		{
			zoomScale = self.maximumZoomScale;
		}
	}
	if (zoomScale != self.zoomScale) // Do zoom
	{
		[self setZoomScale:zoomScale animated:YES];
	}
}


/**
 *	@brief	重置缩放比例
 */
- (void)zoomReset
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	if (self.zoomScale > self.minimumZoomScale)
	{
		self.zoomScale = self.minimumZoomScale;
	}
}


/**
 *	@brief	设置容器视图的背景图片
 *
 *	@param 	backgroundImage	 背景图片
 */
- (void)setTheContainerViewBackgroundImage:(UIImage *)backgroundImage {
  [containerViewBackgroundView setImage:backgroundImage];
}


/**
 *	@brief	设置笔迹图片
 *
 *	@param 	handFrontImage 	笔迹图片
 */
- (void)setHandImage:(UIImage *)handFrontImage {
  [handImageView setImage:handFrontImage];
}

/**
 *	@brief	显示之前的笔迹，
 *
 *	@param 	handImage 	之前存在的笔迹图片
 */
- (void)showNoteView:(UIImage *)handImage {
  noteView = [[NoteView alloc] initWithFrame:theContainerView.frame TouchHandImage:handImage];
  [self addSubview:noteView];
  [handImageView setHidden:YES];
  curMaxZoomScale = self.maximumZoomScale;
  self.maximumZoomScale = self.minimumZoomScale;
  self.scrollEnabled = NO;
//  theContainerView.userInteractionEnabled = NO;
}


/**
 *	@brief	删除之前的笔迹图片，并替换成handImage
 *
 *	@param 	handImage	新的笔迹图片
 */
- (void) hideNoteView:(UIImage *)handImage {
  [noteView removeFromSuperview];
    noteView = nil;
  [handImageView setHidden:NO];
  [handImageView setImage:handImage];
  self.maximumZoomScale = curMaxZoomScale;
  self.scrollEnabled = YES;
//  theContainerView.userInteractionEnabled = YES;
}


/**
 *	@brief	获取pdf的缩略图图片
 *
 *	@return	当前设备上下文的缩略图图片
 */
- (UIImage *) getMicroimageDataOfPDFContent{
  UIGraphicsBeginImageContext(theContainerView.bounds.size);
  [theContentView.layer renderInContext:UIGraphicsGetCurrentContext()];
  UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  return [UIImage reSizeImage:image toSize:CGSizeMake(180.0, 260.0)];
}



#pragma mark UIScrollViewDelegate methods

/**
 *	@brief	获取缩放视图
 *
 *	@param 	scrollView 	当前scrollView容器
 *
 *	@return	当前随着scrollView中捕获手势进行缩放的视图
 */
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
	return theContainerView;
}


/**
 *	@brief	停止缩放之后，重新设置当前缩放比例
 *
 *	@param 	scrollView 	当前scrollView容器
 *	@param 	view 	缩放的视图
 *	@param 	scale{ 	缩放比例
 */
- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)scale{
  self.actualScale = scale;
}


#pragma mark UIResponder instance methods

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesBegan:touches withEvent:event]; // Message superclass
  
	[message contentView:self touchesBegan:touches]; // Message delegate
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesCancelled:touches withEvent:event]; // Message superclass
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesEnded:touches withEvent:event]; // Message superclass
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesMoved:touches withEvent:event]; // Message superclass
}

#pragma mark UIGestureRecognizerDelegate methods

/**
 *	@brief	判断当前手势是否可用，如果在正在批注，则手势不可用
 *
 *	@param 	recognizer 	手势
 *	@param 	touch 	touch对象
 *
 *	@return	手势是否可用
 */
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)recognizer shouldReceiveTouch:(UITouch *)touch
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
  if (noteView)
    return NO;
	return YES;
}

-(void)dealloc{
    NSLog(@"-----%s------",__FUNCTION__);
    [self removeObserver:self forKeyPath:@"frame"];

}

@end
