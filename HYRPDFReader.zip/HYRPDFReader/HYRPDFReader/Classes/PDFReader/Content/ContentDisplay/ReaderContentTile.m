//
//	ReaderContentTile.m
//
//  PDFPageRenderer.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import "ReaderContentTile.h"

@implementation ReaderContentTile

#pragma mark Constants

#define LEVELS_OF_DETAIL 4
#define LEVELS_OF_DETAIL_BIAS 3

#pragma mark ReaderContentTile class methods

/**
 *	@brief	动画时间
 *
 *	@return	动画时间
 */
+ (CFTimeInterval)fadeDuration
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	return 0.001; // iOS bug workaround
}


#pragma mark ReaderContentTile instance methods

- (id)init
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	if ((self = [super init]))
	{
		self.levelsOfDetail = LEVELS_OF_DETAIL;

		self.levelsOfDetailBias = LEVELS_OF_DETAIL_BIAS;

		UIScreen *mainScreen = [UIScreen mainScreen]; // Screen

		CGFloat screenScale = [mainScreen scale]; // Screen scale

		CGRect screenBounds = [mainScreen bounds]; // Screen bounds

		CGFloat w_pixels = (screenBounds.size.width * screenScale);

		CGFloat h_pixels = (screenBounds.size.height * screenScale);

		CGFloat max = ((w_pixels < h_pixels) ? h_pixels : w_pixels);
    
//  CGFloat sizeOfTiles = 512.0f;
  

  

		CGFloat sizeOfTiles = (max < 512.0f) ? 512.0f : 1024.0f;

		self.tileSize = CGSizeMake(sizeOfTiles, sizeOfTiles);
  }

	return self;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif

	//[super dealloc];
}

@end
