//
//	ReaderContentTile.h
//
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

/**
 *	@brief	pdf阅读内容显示界面的分块类。将一个大视图拆分成多个类对象进行显示
 */
@interface ReaderContentTile : CATiledLayer
{
@private
}
@end

