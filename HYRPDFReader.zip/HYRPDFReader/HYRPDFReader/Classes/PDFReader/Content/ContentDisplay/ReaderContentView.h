//
//  ReaderContentView.h
//  PACDMS_ipad
//
//  Created by Z_F Iphone on 11-8-25.
//  Copyright 2011年 zbkc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ReaderContentView;
@class ReaderContentPage;
@class NoteView;

/**
 *	@brief	ReaderContentViewDelegate协议，提供开始在内容显示视图上面触摸动作接口
 */
@protocol ReaderContentViewDelegate <NSObject>

@required // Delegate protocols

/**
 *	@brief	开始在内容显示视图上面触摸动作
 *
 *	@param 	contentView 	当前pdf阅读内容界面
 *	@param 	touches 	开始触摸位置集合
 */
- (void)contentView:(ReaderContentView *)contentView touchesBegan:(NSSet *)touches;


@end

/**
 *	@brief	阅读器内容视图，显示pdf内容的主要视图，提供显示pdf文件内容，pdf页码的批注笔迹，并提供缩放功能
 */
@interface ReaderContentView : UIScrollView <UIScrollViewDelegate,UIGestureRecognizerDelegate>
{
@private // Instance variables

	ReaderContentPage *theContentView;                 // pdf文档的内容显示截图
	UIView *theContainerView;                                // 容器视图
  
  UIImageView *containerViewBackgroundView;     // 容器视图背景图片
  UIImageView *handImageView;                          // 笔迹图片
  NoteView *noteView;                                         // 之前批注的笔迹视图
  
  CGFloat curMaxZoomScale;                                // 当前最大缩放比例
  CGFloat actualScale;                                          // 实际缩放比例
}

/**
 *	@brief	之前批注的笔迹视图
 */
@property (nonatomic,retain) NoteView *noteView;

/**
 *	@brief	实际缩放比例
 */
@property (nonatomic,assign) CGFloat actualScale;

/**
 *	@brief	ReaderContentViewDelegate代理
 */
@property (nonatomic, assign, readwrite) id <ReaderContentViewDelegate> message;

/**
 *	@brief	根据尺寸位置，pdf文档引用，选择页码，缩略图和批注笔迹初始化阅读内容显示界面
 *
 *	@param 	frame 	尺寸位置
 *	@param 	pdfDocumentRef 	pdf文件的引用
 *	@param 	page 	页码
 *	@param 	microImage 	页码的缩略图
 *	@param 	handImage 	批注笔迹
 *
 *	@return	阅读内容显示界面
 */
- (id)initWithFrame:(CGRect)frame 
     pDFDocumentRef:(CGPDFDocumentRef)pdfDocumentRef  
            numPage:(NSUInteger)page 
      pdfMicroImage:(UIImage *)microImage 
       pdfHandImage:(UIImage *)handImage;

/**
 *	@brief	放大，如果当前缩放比例小于最大缩放比例，则判断放大时候的比例如果大于了最大比例，则缩小到最小比例
 */
- (void)zoomIncrement;

/**
 *	@brief	缩小，如果当前缩放比例大于最小缩放比例，则判断缩小时候的比例如果小于了最小比例，则放大到最大比例
 */
- (void)zoomDecrement;

/**
 *	@brief	重置缩放比例
 */
- (void)zoomReset;

/**
 *	@brief	设置容器视图的背景图片
 *
 *	@param 	backgroundImage	 背景图片
 */
- (void) setTheContainerViewBackgroundImage:(UIImage *)backgroundImage;

/**
 *	@brief	显示之前的笔迹，
 *
 *	@param 	handImage 	之前存在的笔迹图片
 */
- (void) showNoteView:(UIImage *)handImage;

/**
 *	@brief	删除之前的笔迹图片，并替换成handImage
 *
 *	@param 	handImage	新的笔迹图片
 */
- (void) hideNoteView:(UIImage *)handImage;

/**
 *	@brief	获取pdf的缩略图图片
 *
 *	@return	当前设备上下文的缩略图图片
 */
- (UIImage *) getMicroimageDataOfPDFContent;

@end

