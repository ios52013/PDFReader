//
//  Squiggle.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "Squiggle.h"

@implementation Squiggle

- (id)init{
    if (self = [super init]) {
        _pointsArray = [[NSMutableArray alloc] init];
        _strokerColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:0.3];
        _lineWidth = 2;
    }
    return self;
}

/**
 *    @brief    将当前点存储到数组中
 *
 *    @param     point     触摸点的位置
 */
- (void)addPoint:(CGPoint)point{
    //这里得用NSValue将结构体类型的CGPoint转换为对象
    NSValue *value = [NSValue valueWithBytes:&point objCType:@encode(CGPoint)];
    [_pointsArray addObject:value];
}

@end
