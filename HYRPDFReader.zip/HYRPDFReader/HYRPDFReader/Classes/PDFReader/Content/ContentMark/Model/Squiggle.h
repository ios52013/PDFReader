//
//  Squiggle.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//
//  每一画的笔迹


#import <UIKit/UIKit.h>

/**
 *    @brief    笔迹对象，存放当前笔迹的属性，点集合，颜色，粗细
 */
@interface Squiggle : NSObject 
/**
 *    @brief    存储每次移动的点的集合
 */
@property (nonatomic,strong)NSMutableArray *pointsArray;

/**
 *    @brief    画笔颜色
 */
@property (nonatomic,strong)UIColor *strokerColor;

/**
 *    @brief    画笔粗细
 */
@property float lineWidth;

/**
 *    @brief    将当前点存储到数组中
 *
 *    @param     point     触摸点的位置
 */
- (void)addPoint:(CGPoint)point;

@end
