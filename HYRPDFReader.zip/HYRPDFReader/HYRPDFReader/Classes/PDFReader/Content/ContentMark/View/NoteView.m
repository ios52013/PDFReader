//
//  NoteView.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "NoteView.h"

@implementation NoteView

/**
 *    @brief    以之前的笔迹初始化视图
 *
 *    @param     frame     视图尺寸和位置
 *    @param     image     上一次绘制过后的笔迹图片
 *
 *    @return    初始化的对象
 */
- (id)initWithFrame:(CGRect)frame TouchHandImage:(UIImage*)image{
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
        if (image) {
            touchHandImage = image;
        }else {
            touchHandImage = [[UIImage alloc] init];
        }
        _theNewNoteView = [[NewNoteView alloc] initWithFrame:self.bounds];
        [self addSubview:_theNewNoteView];
        oldSize = frame.size;
    }
    return self;
}

#pragma mark-
#pragma mark-------- Inherit methods ---------

/**
 *    @brief    重写drawRect方法，绘制之前保存的笔迹图片
 *
 *    @param     rect     绘制区域，自身的frame所指定的尺寸和位置
 */
- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    //重画之前保存的笔迹图片
    
    CGContextSaveGState(context);
    CGContextTranslateCTM(context, 0.0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextDrawImage(context, self.bounds, touchHandImage.CGImage);
    CGContextRestoreGState(context);
}


/**
 *    @brief    重新对子视图进行布局
 */
- (void)layoutSubviews {
    [super layoutSubviews];
    _theNewNoteView.frame = self.bounds;
}



#pragma mark-
#pragma mark-------- Object methods ---------
/**
 *    @brief    设置笔迹粗细
 *
 *    @param     lineWidth     笔迹粗细
 */
- (void)setHandLineWidth:(CGFloat)lineWidth {
    _theNewNoteView.lineWidth = lineWidth;
}

/**
 *    @brief    设置笔迹颜色
 *
 *    @param     lineColor     笔迹颜色
 */
- (void)setHandLineColor:(UIColor *)lineColor {
    _theNewNoteView.lineColor = lineColor;
}

/**
 *    @brief    撤销笔迹
 *
 *    @param     isEraser     是否撤销，YES标示撤销，反之NO
 */
- (void)eraserHand:(BOOL)isEraser {
    [_theNewNoteView removeLastSquiggle];
}

/**
 *    @brief    保存笔迹数据
 *
 *    @return    笔迹数据
 */
- (NSData *)saveHandImageData {
    return [_theNewNoteView getHandImageDataWithSuitSize:oldSize];
}


@end
