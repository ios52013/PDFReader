//
//  NoteView.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewNoteView.h"

/**
 *    @brief    画布视图，显示之前已经有的笔迹。
 */
@interface NoteView : UIView {
    UIImage *touchHandImage;   //之前保留的笔迹图片
   
    CGSize oldSize;                     //原始画布大小
}
//最新画的笔迹
@property (nonatomic,retain)NewNoteView *theNewNoteView;

/**
 *    @brief    以之前的笔迹初始化视图
 *
 *    @param     frame     视图尺寸和位置
 *    @param     image     上一次绘制过后的笔迹图片
 *
 *    @return    初始化的对象
 */
- (id)initWithFrame:(CGRect)frame TouchHandImage:(UIImage*)image;

/**
 *    @brief    设置笔迹粗细
 *
 *    @param     lineWidth     笔迹粗细
 */
- (void)setHandLineWidth:(CGFloat)lineWidth;

/**
 *    @brief    设置笔迹颜色
 *
 *    @param     lineColor     笔迹颜色
 */
- (void)setHandLineColor:(UIColor *)lineColor;

/**
 *    @brief    撤销笔迹
 *
 *    @param     isEraser     是否撤销，YES标示撤销，反之NO
 */
- (void)eraserHand:(BOOL)isEraser;

/**
 *    @brief    保存笔迹数据
 *
 *    @return    笔迹数据
 */
- (NSData *)saveHandImageData;
@end
