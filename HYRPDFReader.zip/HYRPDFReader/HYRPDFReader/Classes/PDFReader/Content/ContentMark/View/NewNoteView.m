//
//  NewNoteView.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "NewNoteView.h"
#import "UIImage+HYRComponent.h"

@implementation NewNoteView
#pragma mark-------- Init ---------

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
        squigglesDic = [[NSMutableDictionary alloc] init];
        finishSquiggles = [[NSMutableArray alloc] init];
        allSquigglleKeys = [[NSMutableArray alloc] init];
        isHandMove = NO;
        _lineWidth = DefaultSquiggleLineWidth;//默认笔迹大小
        _lineColor = [[UIColor alloc] initWithRed:1 green:0 blue:0 alpha:0.5];//默认笔迹颜色(红色)
    }
    return self;
}


#pragma mark-
#pragma mark-------- Inherit methods ---------

/**
 *    @brief    重写drawRect方法，绘制所有笔迹
 *
 *    @param     rect     绘制区域，自身的frame所指定的尺寸和位置
 */
- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    for(Squiggle *squiggle in finishSquiggles)
    {
        [self drawSquiggle:squiggle inContext:context];
    }
    for(NSString *key in squigglesDic)
    {
        Squiggle *squiggle = [squigglesDic valueForKey:key];
        [self drawSquiggle:squiggle inContext:context];
    }
}


/**
 *    @brief    重写UIView的方法，触摸点开始记录,一移动再记录,这样就记录无数多个点便成了线
 *
 *    @param     touches     存放触摸开始的点的集合
 *    @param     event     触摸事件
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    isHandMove = NO;
    NSArray *array = [touches allObjects];
    for(UITouch *touch in array)
    {
        Squiggle *squiggle = [[Squiggle alloc] init];
        squiggle.lineWidth = _lineWidth;
        squiggle.strokerColor = _lineColor;
        //self  指当前这次触摸事件
        [squiggle addPoint:[touch locationInView:self]];
        //因为每次触摸事件的内存地址唯一,所以将其作为 squiggle的关键字key
        //将内存地址转换为对象
        //NSValue *touchValue = [NSValue valueWithPointer:touch];
        NSValue *touchValue = [NSValue valueWithPointer:(__bridge void*)touch];
        NSString *key = [NSString stringWithFormat:@"%@",touchValue];
        [squigglesDic setValue:squiggle forKey:key];
        [allSquigglleKeys addObject:key];
       
    }
}


/**
 *    @brief    重写UIView的方法，触摸移动时保存移动路径下的每一个点的坐标信息。
 *
 *    @param     touches     触摸点的集合
 *    @param     event     触摸事件
 */
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    isHandMove = YES;
    NSArray *array = [touches allObjects];
    for(UITouch *touch in array) {
        //这里因为在前面 touchBegan中已经存好了相应的key,每一次触摸都有一关键字对应,这里只是在触摸的基础上移动画点
        NSValue *touchValue = [NSValue valueWithPointer:(__bridge void*)touch];
        Squiggle *squiggle = [squigglesDic valueForKey:[NSString stringWithFormat:@"%@",touchValue]];
        CGPoint current = [touch locationInView:self];
        CGPoint previous = [touch previousLocationInView:self];
        //一直将当前点加进pointsArray中
        [squiggle addPoint:current];
        //更新后,得声明重新执行下 drawRect方法,系统不会自动执行
        CGPoint lower,higher;
        lower.x = (previous.x > current.x ? current.x : previous.x);
        lower.y = (previous.y > current.y ? current.y : previous.y);
        higher.x = (previous.x < current.x ? current.x : previous.x);
        higher.y = (previous.y < current.y ? current.y : previous.y);
        // redraw the screen in the required region
        [self setNeedsDisplayInRect:CGRectMake(lower.x-squiggle.lineWidth,
                                               lower.y-squiggle.lineWidth, higher.x - lower.x + squiggle.lineWidth*2,
                                               higher.y - lower.y + squiggle.lineWidth * 2)];
    }
}


/**
 *    @brief    重写UIView的方法，一次连贯的绘制结束只有，保存这次绘制的笔迹，并重画视图
 *
 *    @param     touches     结束点存放的集合
 *    @param     event     触摸事件
 */
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    if (!isHandMove) {
        
        //记录单击的点
        isHandMove = YES;
        NSValue *touchValue = [NSValue valueWithPointer:(__bridge void*)theTouch];
        NSString *key = [NSString stringWithFormat:@"%@",touchValue];
        Squiggle *squiggle = [squigglesDic valueForKey:key];
        paiterPoint = [theTouch locationInView:self];
        paiterPoint = CGPointMake(paiterPoint.x, paiterPoint.y-4);
        CGPoint current = paiterPoint;
        CGPoint previous = [theTouch locationInView:self];
        [squiggle addPoint:current];
        
        //更新后,得声明重新执行下 drawRect方法,系统不会自动执行
        CGPoint lower,higher;
        lower.x = (previous.x > current.x ? current.x : previous.x);
        lower.y = (previous.y > current.y ? current.y : previous.y);
        higher.x = (previous.x < current.x ? current.x : previous.x);
        higher.y = (previous.y < current.y ? current.y : previous.y);
        
        [self setNeedsDisplayInRect:CGRectMake(lower.x-squiggle.lineWidth,
                                               lower.y-squiggle.lineWidth, higher.x - lower.x + squiggle.lineWidth*2,
                                               higher.y - lower.y + squiggle.lineWidth * 2)];
        [finishSquiggles addObject:squiggle];
        [squigglesDic removeObjectForKey:key];
    }else {
        for(UITouch *touch in touches)
        {
            //NSValue *touchValue = [NSValue valueWithPointer:touch];
            NSValue *touchValue = [NSValue valueWithPointer:(__bridge void*)touch];
            NSString *key = [NSString stringWithFormat:@"%@",touchValue];
            Squiggle *squiggle = [squigglesDic valueForKey:key];
            [finishSquiggles addObject:squiggle];
            [squigglesDic removeObjectForKey:key];
        }
    }
}



#pragma mark-
#pragma mark-------- Object methods ---------

/**
 *    @brief    在图形上下文中画线
 *
 *    @param     squiggle     曲线对象
 *    @param     context     图形上下文
 */
- (void)drawSquiggle:(Squiggle *)squiggle inContext:(CGContextRef)context {
    UIColor *squiggleColor = squiggle.strokerColor;
    CGColorRef colorRef = [squiggleColor CGColor];
    CGContextSetStrokeColorWithColor(context, colorRef);
    
    CGContextSetLineWidth(context, squiggle.lineWidth);
    
    NSMutableArray *pointArray1 = [squiggle pointsArray];
    
    CGPoint firstPoint;
    //复制第1个元素值到firstPoint点中
    [[pointArray1 objectAtIndex:0] getValue:&firstPoint];
    CGContextMoveToPoint(context, firstPoint.x, firstPoint.y);
    for(int i = 1; i<[pointArray1 count];i++)
    {
        NSValue *value = [pointArray1 objectAtIndex:i];
        CGPoint point ;
        //将下一个点复制值,然后再在这两点之间画线
        [value getValue:&point];
        CGContextAddLineToPoint(context, point.x, point.y);
    }
    
    CGContextStrokePath(context);
}

/**
 *    @brief    获取合适大小的批注二进制数据
 *
 *    @param     suitSize     合适的大小
 *
 *    @return    批注二进制数据
 */
- (NSData *)getHandImageDataWithSuitSize:(CGSize)suitSize {
    //只有当前有添加笔迹时才需要保存，否则不需要保存
    NSData *data = nil;
    if (isHandMove && [finishSquiggles count]>0) {
        //将当前笔迹图片和父类中旧的图片笔迹作为图片数据保存
        UIGraphicsBeginImageContext(self.bounds.size);
        [self.superview.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        viewImage = [UIImage reSizeImage:viewImage toSize:suitSize];
        data = UIImagePNGRepresentation(viewImage);
    }
    return data;
}

/**
 *    @brief    撤销（删除）曲线
 */
- (void)removeLastSquiggle {
    if ([finishSquiggles count]>0) {
        [finishSquiggles removeLastObject];
    }
    if ([squigglesDic count]>0 && [allSquigglleKeys count] > 0) {
        [squigglesDic objectForKey:[allSquigglleKeys objectAtIndex:[allSquigglleKeys count]-1]];
        [allSquigglleKeys removeLastObject];
    }
    [self setNeedsDisplay];
}

@end
