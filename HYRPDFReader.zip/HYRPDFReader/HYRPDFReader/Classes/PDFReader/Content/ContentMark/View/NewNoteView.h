//
//  NewNoteView.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//
//  显示最新添加的笔迹

//默认笔迹大小
#define DefaultSquiggleLineWidth  2.0

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "Squiggle.h"

@interface NewNoteView : UIView {
    
    NSMutableDictionary *squigglesDic;  //一次连贯绘制的笔迹对象（包含点集合，颜色，粗细）的集合的集合
    NSMutableArray *finishSquiggles;    //所有绘制的笔迹对象
    NSMutableArray *allSquigglleKeys;   //所有笔迹对象的键值
    
    CGPoint paiterPoint;                          //单击的点
    BOOL isHandMove;                           //判断当前操作是不是单击的点
    
    
}

/**
 *    @brief    笔迹对象的粗细
 */
@property (nonatomic, assign)CGFloat lineWidth;

/**
 *    @brief    笔迹对象的颜色
 */
@property (nonatomic, strong)UIColor *lineColor;


/**
 *    @brief    在图形上下文中画线
 *
 *    @param     squiggle     曲线对象
 *    @param     context     图形上下文
 */
- (void)drawSquiggle:(Squiggle *)squiggle inContext:(CGContextRef)context;

/**
 *    @brief    获取合适大小的批注二进制数据
 *
 *    @param     suitSize     合适的大小
 *
 *    @return    批注二进制数据
 */
- (NSData *)getHandImageDataWithSuitSize:(CGSize)suitSize;

/**
 *    @brief    撤销（删除）曲线
 */
- (void)removeLastSquiggle;

@end

