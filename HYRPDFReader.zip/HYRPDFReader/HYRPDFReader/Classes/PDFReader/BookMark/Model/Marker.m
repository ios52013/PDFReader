//
//  Marker.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/4.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "Marker.h"

//定义 各个 属性在编码和解码时的 键值
#define kDateKey                @"tagDate"
#define kPageKey                 @"page"
#define kChapterKey            @"chapter"
#define kTouchHandKey        @"touchHandData"
#define kPretendViewKey      @"pretendViewData"

@interface Marker ()

// NSCoding delegate
/**
 *    @brief    将类中的各个属性进行编码， 在编码这个类的对象时自动调用
 *
 *    @param     encoder     编码器对象
 */
- (void)encodeWithCoder:(NSCoder *)encoder;

/**
 *    @brief    将类中的各个属性进行解码， 解码后返回一个类的实例， 在解码类对象时自动调用
 *
 *    @param     decoder     解码器对象
 *
 *    @return    返回通过解码得到的Marker对象
 */
- (id)initWithCoder:(NSCoder *)decoder;


//NSCopying delegate
/**
 *    @brief    实现NSObject的copyWithZone:方法，使Marker对象能够使用copy方法
 *
 *    @param     zone     对象域
 *
 *    @return    返回通过copy解码后得到的Marker对象
 */
- (id)copyWithZone:(NSZone *)zone;


@end

@implementation Marker

@synthesize tagDate;
@synthesize page;
@synthesize chapter;
@synthesize touchHandData;
@synthesize pretendViewData;


#pragma mark ========  NSCoding delegate =======

-(void) encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:tagDate forKey:kDateKey];
    [encoder encodeInteger:page forKey:kPageKey];
    [encoder encodeInteger:chapter forKey:kChapterKey];
    [encoder encodeObject:touchHandData forKey:kTouchHandKey];
    [encoder encodeObject:pretendViewData forKey:kPretendViewKey];
}

-(id) initWithCoder:(NSCoder *)decoder{
    if(self = [super init]){
        self.tagDate = [decoder decodeObjectForKey:kDateKey];
        self.page = [decoder decodeIntegerForKey:kPageKey];
        self.chapter = [decoder    decodeIntegerForKey:kChapterKey];
        self.touchHandData = [decoder decodeObjectForKey:kTouchHandKey];
        self.pretendViewData = [decoder decodeObjectForKey:kPretendViewKey];
    }
    return self;
}


#pragma mark ======== NSCopying delegate =======

-(id) copyWithZone:(NSZone *)zone{
    Marker *_copy = [[[self class] allocWithZone:zone] init];
    _copy.tagDate = [self.tagDate copyWithZone:zone];
    _copy.touchHandData = [self.touchHandData copyWithZone:zone];
    _copy.pretendViewData = [self.pretendViewData copyWithZone:zone];
    _copy.page = self.page;
    _copy.chapter = self.chapter;
    return _copy;
}

@end
