//
//  Marker.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/4.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *    @brief    保存批注信息的模型类，批注信息包括批注时间，批注页码，批注章节等
 */
@interface Marker : NSObject<NSCoding,NSCopying> {
    NSString *tagDate;                  //添加批注时的日期
    NSInteger page;                      //批注对应pdf的页码
    NSInteger chapter;                 //章节
    NSData *touchHandData;         //触摸笔迹图片的二进制值，在阅读PDF内容时显示
    NSData *pretendViewData;      //页面截图的二进制值，用来在批注缩略页中显示
}

/**
 *    @brief    标示添加批注的时间
 */
@property (nonatomic, retain) NSString *tagDate;

/**
 *    @brief    标示批注对应的页码
 */
@property (nonatomic, assign) NSInteger page;

/**
 *    @brief    标示批注对应的章节
 */
@property (nonatomic, assign) NSInteger chapter;

/**
 *    @brief    批注笔迹图片的二进制表示，在阅读pdf的时候显示到pdf上
 */
@property (nonatomic, retain) NSData *touchHandData;

/**
 *    @brief    当前批注页截图的二进制表示，用来在批注缩略查看页中显示
 */
@property (nonatomic, retain) NSData *pretendViewData;

@end
