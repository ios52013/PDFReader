//
//  BookMarkViewController.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "BookMarkViewController.h"
#import "HYRPDFReaderViewController.h"
//#import "AgendaViewController.h"
//#import "AgendaMeta.h"
#import "HYRFileMeta.h"
#import "Marker.h"
//#import "ComstomNaviControllerViewController.h"
#import "UIColor+HYRComponent.h"
//#import "Masonry.h"
#import "UIView+Extension.h"


@interface BookMarkViewController () //<ComstomNaviDelegate>
/***声明 属性***/
//@property (nonatomic, strong) ComstomNaviControllerViewController  *cusNavigationController;

//当前显示的资料
@property(nonatomic,strong) id curMaterial;
//当前显示的资料
@property(nonatomic,strong) HYRFileMeta *curFileMeta;
//当前通知的资料
//@property(nonatomic,strong) NoticeAttachmentMate *curNoticeMeta;
////当前日常文件的资料
//@property(nonatomic,strong) GenericFileMeta *curGenericMeta;
////当前历史文件的资料
//@property(nonatomic,strong) HistoryFileMeta *curHistoryMeta;


@end


//竖屏显示4列
static NSInteger kPortraitComponent = 4;
//横屏显示6列
static NSInteger kLandscapeComponent = 6;
//一页有12个
static NSInteger kMarkViewInOnePage = 12;
static NSInteger kBeginBookMarkViewTag = 100;

NSInteger const KPageControlBackViewTag = 99;




@implementation BookMarkViewController

- (id)init {
    if (self = [super init]) {
        _curPage = 0;
        _isMemoryWarning = NO;
    }
    return self;
}



#pragma mark - 根据pdf文档的某一页页码生成书签
- (void)initMarkViewForPage:(int)page {
    CGRect viewFrame = CGRectZero;
    NSInteger numberComponent = 0;
    NSInteger numberRow = 0;
    NSInteger numberCount = 0;
    NSInteger numberPage = page;
    NSInteger maxMarkView = 0;
    NSInteger countAllBookMark = [_allBookMarkArray count];
    if (countAllBookMark == 0) {
        return;
    }
    
    switch (page) {
        case 0:
            if (countAllBookMark < kMarkViewInOnePage)
                maxMarkView = countAllBookMark;
            else
                maxMarkView = kMarkViewInOnePage;
            break;
        case 1:
            if (countAllBookMark < kMarkViewInOnePage * 2)
                maxMarkView = countAllBookMark;
            else
                maxMarkView = kMarkViewInOnePage * 2;
            break;
            
        default:
            break;
    }
    
    //增加新的BookMarkView
    if (page * kMarkViewInOnePage >= maxMarkView) {
        return;
    }
    
    //竖屏下 每个书签横向距离
    float PortraitSpaceX = (_bookRemarkView.width -(kPortraitComponent *BOOKMARKVIEW_WIDTH))/(kPortraitComponent-1);
    
    for (NSInteger i = page*kMarkViewInOnePage; i < maxMarkView; i++) {
        
        BookMarkView *bookMarkView = nil;
        CGFloat viewFrameX = 0.0;
        //列数
        numberComponent = numberCount%kPortraitComponent + 1;
        //行数
        numberRow = (int)ceil((numberCount + 0.01)/kPortraitComponent);
        //
        viewFrameX= PortraitSpaceX + BOOKMARKVIEW_WIDTH*(numberComponent - 1) + numberPage*BOOKMARKVIEW_SCROLLVIEW_WIDTH;
        viewFrame = CGRectMake(viewFrameX, 45.0 + 285.0*(numberRow - 1), BOOKMARKVIEW_WIDTH, BOOKMARKVIEW_HEIGHT);
        
        //创建一页标注的书签
        bookMarkView = [[BookMarkView alloc] initWithFrame:viewFrame];
        [bookMarkView setDelegate:self];
        [bookMarkView setPage:numberPage];
        [bookMarkView setRow:numberRow];
        [bookMarkView setComponent:numberComponent];
        [bookMarkView setDeleteButttonHidden:NO];
        Marker *marker = (Marker *)[_allBookMarkArray objectAtIndex:i];
        //pdf page
        [bookMarkView setPDFPage:marker.page];
        [bookMarkView setChapter:marker.chapter];
        [bookMarkView setBookMarkViewBackImage:[UIImage imageWithData:marker.pretendViewData]];
        [bookMarkView setTag:kBeginBookMarkViewTag + numberPage*kMarkViewInOnePage + numberCount];
        [_bookRemarkView addSubview:bookMarkView];
        [_allMarkViewArray replaceObjectAtIndex:i withObject:bookMarkView];
        
        numberCount ++;
    }
}



#pragma mark - 初始化所有书签缩略图
- (void)initAllBookMarkView {
    if (_allMarkViewArray){
        _allMarkViewArray = nil;
    }
        
    _allMarkViewArray = [NSMutableArray array];
    int countMarkView = 0;
    
    if ([_allBookMarkArray count] < kMarkViewInOnePage*2)
        countMarkView = [_allBookMarkArray count];
    else
        countMarkView = kMarkViewInOnePage *2;
    
    for (int i = 0; i < countMarkView; i++) {
        [_allMarkViewArray addObject:[NSNull null]];
    }
    
    [self initMarkViewForPage:0];
    [self initMarkViewForPage:1];
}

#pragma mark =======    加载界面     =======

#pragma mark - 加载顶部导航栏
//- (void)addNavgationButton {
//    
//    self.cusNavigationController= [ComstomNaviControllerViewController CreateComstomNvTiltleName:NSLocalizedString(@"关于会议的会议资料", nil) WithTitleFont: [UIFont fontWithName:@"PingFangSC-Regular" size:20] WithLeftButtons:nil WithRightButtons:nil];
//    self.cusNavigationController.delegate = self;
//    //自动调整view的宽度，保证左边距和右边距不变
//    [self.cusNavigationController setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
//    [self.view addSubview:self.cusNavigationController];
//    [self.cusNavigationController mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.left.right.offset(0);
//        make.height.offset(80);
//    }];
//    
//    [self.cusNavigationController setBanckGroundCorlor:[UIColor colorWithHexString:@"#565656" alpha:1.0] WithAplphl:1.0];
//    [self.cusNavigationController setTiletelabelWithArgmernt:NSTextAlignmentCenter];
//    [self.cusNavigationController setTiltelabelWithCorlor:[UIColor whiteColor]];
//    
//}

//导航栏返回按钮触发的事件回调
-(void)CickRetuned:(id)obj{
    
    
    if(self.navigationController){
        
        [self saveHandDataToLocalWithCommentArr:_allBookMarkArray];
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }else{
        
        [self saveHandDataToLocalWithCommentArr:_allBookMarkArray];
        
//        AppDelegate*dele = (AppDelegate *)[UIApplication sharedApplication].delegate;
//        [dele.navigation popViewControllerAnimated:YES];
        
    }
}


#pragma mark -   加载内容视图
- (void)loadContentView {
    _contentView = [[UIView alloc] initWithFrame:CGRectMake(CONTENTVIEW_PORTRAIT_X,
                                                            CONTENTVIEW_Y,
                                                            kScreenWidth,
                                                            kScreenHeight)];
    [self.view addSubview:_contentView];
    [_contentView setBackgroundColor:[UIColor clearColor]];
    
    //加载书签缩略图视图
    [self loadBookMarkView];
    
}


#pragma mark - 加载书签缩略图视图 UIScrollView
- (void)loadBookMarkView {
    
    CGRect frame = CGRectMake(BOOKMARKVIEW_SCROLLVIEW_X,
                              BOOKMARKVIEW_SCROLLVIEW_Y,
                              BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                              BOOKMARKVIEW_SCROLLVIEW_HEIGHT);
    
    _bookRemarkView = [[UIScrollView alloc] initWithFrame:frame];
    [_bookRemarkView setBackgroundColor:[UIColor clearColor]];
    [_bookRemarkView setDelegate:self];
    [_bookRemarkView setShowsVerticalScrollIndicator:NO];
    [_bookRemarkView setShowsHorizontalScrollIndicator:NO];
    [_bookRemarkView setPagingEnabled:YES];
    [_contentView addSubview:_bookRemarkView];
    if (@available(iOS 11.0, *)) {
        _bookRemarkView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }else{
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
}




/**
 *    @brief    加载 分页导航控件
 */
- (void)loadPageControl {
    _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(BOOKMARKVIEW_PAGECONTROL_X,
                                                                   BOOKMARKVIEW_PAGECONTROL_Y,
                                                                   BOOKMARKVIEW_PAGECONTROL_WIDTH,
                                                                   BOOKMARKVIEW_PAGECONTROL_HEIGHT)];
    
    [_bookRemarkView setContentSize:CGSizeMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH * _totalPage,
                                               BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
    
    [_pageControl addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventValueChanged];
    
    UIImageView *pageControlBackImageView = [[UIImageView alloc] initWithFrame:_pageControl.bounds];
    [pageControlBackImageView setImage:[[UIImage imageNamed:@"icon_pagecontrol.png"] stretchableImageWithLeftCapWidth:10.0 topCapHeight:0]];
    [pageControlBackImageView setTag:KPageControlBackViewTag];
    [_pageControl addSubview:pageControlBackImageView];
    [_pageControl setCurrentPage:0];
    [_contentView addSubview:_pageControl];
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -
#pragma mark =======    逻辑处理     =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark ----     公有接口  ----

#pragma mark - 设置书签对象数组
- (void)setAllBookMarkArray:(NSMutableArray *)allBookMarkArray {
    if (_allBookMarkArray) {
        _allBookMarkArray = nil;
    }
    _allBookMarkArray = allBookMarkArray;
    //初始化所有书签缩略图
    [self initAllBookMarkView];
    _totalPage = ceil([_allBookMarkArray count]/(kMarkViewInOnePage*1.0));
    
    [_pageControl setNumberOfPages:_totalPage];
    
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        [_bookRemarkView setContentSize:CGSizeMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH * _totalPage,
                                                   BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
        [self resetBookMarkViewFrameForDevicePortraitDirection:YES Page:_curPage];
    }
    else{
        [_bookRemarkView setContentSize:CGSizeMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH * _totalPage,
                                                   BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
        [self resetBookMarkViewFrameForDevicePortraitDirection:NO Page:_curPage];
    }
    
}




#pragma mark - 显示指定会议资料的批注
- (void)showBookMarkWithFileMeta:(id)meta {
    [self clearMemoryData];
    
    _curMaterial = meta;
    
    _isPushFromPDFReadView = NO;
   
    NSString *remarkPath = nil;

    //- 判断文件类型
    if ([meta isKindOfClass:[HYRFileMeta class]]) {
        HYRFileMeta *fileMeta = (HYRFileMeta *)meta;
        //设置标题
//        self.cusNavigationC?ontroller.titlelabel.text = fileMeta.materialname;
        //FileMeta *localMaterial = [[[FileMeta alloc] init] materialFromSqliteWithMaterialID:fileMeta.materialid];
//        remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:fileMeta.materialid];
        
    }
//    else if ([meta isKindOfClass:[NoticeAttachmentMate class]]) {
//        //通知文件
//        NoticeAttachmentMate *noticMeta = (NoticeAttachmentMate *)meta;
//        //设置标题
//        self.cusNavigationController.titlelabel.text = noticMeta.materialname;
//        remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:noticMeta.materialid];
//
//    }else if ([meta isKindOfClass:[GenericFileMeta class]]) {
//        //日常文件
//        GenericFileMeta *genericMeta = (GenericFileMeta *)meta;
//        //设置标题
//        self.cusNavigationController.titlelabel.text = genericMeta.materialname;
//        remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:genericMeta.materialid];
//
//    }else if ([meta isKindOfClass:[HistoryFileMeta class]]) {
//        //历史文件
//        HistoryFileMeta *historyMeta = (HistoryFileMeta *)meta;
//        //设置标题
//        self.cusNavigationController.titlelabel.text = historyMeta.materialname;
//        remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:historyMeta.materialid];
//    }
  
//    NSMutableArray *tempMutableArray = [DataBaseManager loadDataFromFile:remarkPath];
   
    //[self setAllBookMarkArray:tempMutableArray];
}



#pragma mark ----     私有接口      ----

/**
 *    @brief    清空内存数据
 */
- (void)clearMemoryData{
    _curPage = 0;
    [_pageControl setCurrentPage:0];
    //删除bookMarkView
    for(UIView *view in [_bookRemarkView subviews]) {
        if (view.tag > 99) {
            [view removeFromSuperview];
        }
    }
}


#pragma mark - 竖屏布局
- (void)relayoutElementsForPortrait{
//    [_cusNavigationController setFrame:CGRectMake(0, 0, kScreenWidth, 80)];
//    [_cusNavigationController.titlelabel setFrame:CGRectMake(kScreenWidth*0.5-160, 80-16-28, 320, 28)];
    
    [_contentView setFrame:CGRectMake(CONTENTVIEW_PORTRAIT_X,
                                      CONTENTVIEW_Y,
                                      kScreenWidth,
                                      kScreenHeight)];
  
    [_bookRemarkView setFrame:CGRectMake(BOOKMARKVIEW_SCROLLVIEW_X,
                                         BOOKMARKVIEW_SCROLLVIEW_Y,
                                         BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                         BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
    
    [_pageControl setFrame:CGRectMake(BOOKMARKVIEW_PAGECONTROL_X,
                                      BOOKMARKVIEW_PAGECONTROL_Y,
                                      BOOKMARKVIEW_PAGECONTROL_WIDTH,
                                      BOOKMARKVIEW_PAGECONTROL_HEIGHT)];
    
    UIImageView *tempImageView = (UIImageView *)[_pageControl viewWithTag:KPageControlBackViewTag];
    [tempImageView setFrame:_pageControl.bounds];
    [tempImageView setImage:[[UIImage imageNamed:@"icon_pagecontrol.png"] stretchableImageWithLeftCapWidth:10.0 topCapHeight:0]];
    int page = 0;
    if (_curPage == 0) {
        page = 0;
    }else{
        page = _curPage - 1;
    }
    [self resetBookMarkViewFrameForDevicePortraitDirection:YES Page:page];
}



#pragma mark - 横屏布局
- (void)relayoutElementsForLandscape{
//    [_cusNavigationController setFrame:CGRectMake(0, 0, kScreenWidth, 80)];
//    [_cusNavigationController.titlelabel setFrame:CGRectMake(kScreenWidth*0.5-160, 80-16-28, 320, 28)];
    
    [_contentView setFrame:CGRectMake(CONTENTVIEW_PORTRAIT_X,
                                      CONTENTVIEW_Y,
                                      kScreenWidth,
                                      kScreenHeight)];
    
    [_bookRemarkView setFrame:CGRectMake(BOOKMARKVIEW_SCROLLVIEW_X,
                                         BOOKMARKVIEW_SCROLLVIEW_Y,
                                         BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                         BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
    
    [_pageControl setFrame:CGRectMake(BOOKMARKVIEW_PAGECONTROL_X,
                                      BOOKMARKVIEW_PAGECONTROL_Y,
                                      BOOKMARKVIEW_PAGECONTROL_WIDTH,
                                      BOOKMARKVIEW_PAGECONTROL_HEIGHT)];
    
    UIImageView *tempImageView = (UIImageView *)[_pageControl viewWithTag:KPageControlBackViewTag];
    [tempImageView setFrame:_pageControl.bounds];
    [tempImageView setImage:[[UIImage imageNamed:@"icon_pagecontrol.png"] stretchableImageWithLeftCapWidth:10.0 topCapHeight:0]];
    int page = 0;
    if (_curPage == 0) {
        page = 0;
    }else{
        page = _curPage - 1;
    }
    [self resetBookMarkViewFrameForDevicePortraitDirection:NO Page:page];
}


/**
 *    @brief    横竖屏转换时重先设置BookMarkView的frame
 *
 *    @param     isPortrait     横竖屏标志
 *    @param     page     当前是第几页
 */
#pragma mark - 横竖屏转换时重先设置BookMarkView的frame
- (void)resetBookMarkViewFrameForDevicePortraitDirection:(BOOL)isPortrait Page:(int)page {
    
//    [_cusNavigationController setFrame:CGRectMake(0, 0, kScreenWidth, 80)];
//    [_cusNavigationController.titlelabel setFrame:CGRectMake(kScreenWidth*0.5-160, 80-16-28, 320, 28)];
//
    
    
    if (isPortrait) {
        
        [_bookRemarkView setContentSize:CGSizeMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH * _totalPage,
                                                   BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
        [_bookRemarkView setContentOffset:CGPointMake(_curPage * BOOKMARKVIEW_SCROLLVIEW_WIDTH, 0.0) animated:YES];
    }else{
        [_bookRemarkView setContentSize:CGSizeMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH * _totalPage,
                                                   BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
        [_bookRemarkView setContentOffset:CGPointMake(_curPage * BOOKMARKVIEW_SCROLLVIEW_WIDTH, 0.0) animated:YES];
    }
    CGRect viewFrame = CGRectZero;
    int numberComponent = 0;
    int numberRow = 0;
    int numberCount = 0;
    int numberPage = page;
    
    
    //横屏下 每个书签横向距离
    float LandSpaceX = (_bookRemarkView.width -(kLandscapeComponent *BOOKMARKVIEW_WIDTH))/(kLandscapeComponent-1);
    float PortraitSpaceX = (_bookRemarkView.width -(kPortraitComponent *BOOKMARKVIEW_WIDTH))/(kPortraitComponent-1);
    
    for (int i = 0; i<[_allMarkViewArray count]; i++) {
        
        if (isPortrait) {
            numberComponent = numberCount%kPortraitComponent + 1;
            numberRow = (int)ceil((numberCount + 0.01)/kPortraitComponent);
            CGFloat viewFrameX = (PortraitSpaceX + BOOKMARKVIEW_WIDTH)*(numberComponent - 1) + numberPage * BOOKMARKVIEW_SCROLLVIEW_WIDTH;
            viewFrame = CGRectMake(viewFrameX, 45.0 + 285.0*(numberRow - 1), BOOKMARKVIEW_WIDTH, BOOKMARKVIEW_HEIGHT);
            
        }else{
            
            numberComponent = numberCount%kLandscapeComponent + 1;
            numberRow = (int)ceil((numberCount + 0.01)/kLandscapeComponent);
            CGFloat viewFrameX = (LandSpaceX + BOOKMARKVIEW_WIDTH)*(numberComponent - 1) + numberPage *BOOKMARKVIEW_SCROLLVIEW_WIDTH;
            viewFrame = CGRectMake(viewFrameX, 45.0 + 300.0*(numberRow - 1), BOOKMARKVIEW_WIDTH, BOOKMARKVIEW_HEIGHT);
        }
        
        
        if ([_allMarkViewArray objectAtIndex:i]!=[NSNull null]) {
            BookMarkView *bookMarkView = (BookMarkView *)[_bookRemarkView viewWithTag:kBeginBookMarkViewTag + numberPage*kMarkViewInOnePage + numberCount];
            [bookMarkView setPage:numberPage];
            [bookMarkView setRow:numberRow];
            [bookMarkView setComponent:numberComponent];
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.3];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            [bookMarkView setFrame:viewFrame];
            [UIView commitAnimations];
            [bookMarkView setDelegate:self];
        }
        if ((i+1)%12 == 0) {
            numberCount  = 0;
            numberPage ++;
        }else
            numberCount ++;
    }
    
//    [self.cusNavigationController mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.top.left.right.offset(0);
//    }];
    
    [UIView animateWithDuration:0.1 animations:^{
//        [self.cusNavigationController layoutIfNeeded];
    }];
}

/**
 *    @brief    添加书签到指定页面
 *
 *    @param     num     某个页面的第几个书签，总共是kMarkViewInOnePage个
 *    @param     page     在第几个页面添加书签
 *    @param     isPortrait     横竖屏标志
 *
 *    @return    存储书签对象的数组
 */
- (NSMutableArray *)addBookMarkViewWithNumber:(int)num InOnePage:(int)page DeviceDirection:(BOOL)isPortrait {
    NSMutableArray *newBookMarkViewArray = [NSMutableArray array];
    CGRect viewFrame = CGRectZero;
    int numberComponent = 0;
    int numberRow = 0;
    int numberCount = 0;
    int numberPage = page;
    
    
    //横屏下 每个书签横向距离
    float LandSpaceX = (_bookRemarkView.width -(kLandscapeComponent *BOOKMARKVIEW_WIDTH))/(kLandscapeComponent-1);
    float PortraitSpaceX = (_bookRemarkView.width -(kPortraitComponent *BOOKMARKVIEW_WIDTH))/(kPortraitComponent-1);
    
    for (int i = 0; i < num; i++) {
        CGFloat viewFrameX = 0.0;
        //如果是竖屏
        if (isPortrait) {
            numberComponent = numberCount%kPortraitComponent + 1;
            numberRow = (int)ceil((numberCount + 0.01)/kPortraitComponent);
            viewFrameX= (PortraitSpaceX + BOOKMARKVIEW_WIDTH)*(numberComponent - 1) + numberPage*BOOKMARKVIEW_SCROLLVIEW_WIDTH;
            viewFrame = CGRectMake(viewFrameX, 45.0 + 285.0*(numberRow - 1), 155.0, 205.0);
        }
        else
        {
            //如果是横屏
            numberComponent = numberCount%kLandscapeComponent + 1;
            numberRow = (int)ceil((numberCount + 0.01)/kLandscapeComponent);
            viewFrameX = (LandSpaceX + BOOKMARKVIEW_WIDTH)*(numberComponent - 1) + numberPage*BOOKMARKVIEW_SCROLLVIEW_WIDTH;
            viewFrame = CGRectMake(viewFrameX, 45.0 + 300.0*(numberRow - 1), 155.0, 205.0);
        }
        
        BookMarkView *bookMarkView = [[BookMarkView alloc] initWithFrame:viewFrame];
        [bookMarkView setDelegate:self];
        [bookMarkView setPage:numberPage];
        [bookMarkView setRow:numberRow];
        [bookMarkView setComponent:numberComponent];
        [bookMarkView setDeleteButttonHidden:NO];
        Marker *marker = (Marker *)[_allBookMarkArray objectAtIndex:numberPage*kMarkViewInOnePage + i];
        [bookMarkView setPDFPage:marker.page];
        [bookMarkView setChapter:marker.chapter];
        [bookMarkView setBookMarkViewBackImage:[UIImage imageWithData:marker.pretendViewData]];
        [bookMarkView setTag:kBeginBookMarkViewTag + numberPage*kMarkViewInOnePage + numberCount];
        [_bookRemarkView addSubview:bookMarkView];
        [newBookMarkViewArray addObject:bookMarkView];
        
        numberCount ++;
    }
    return newBookMarkViewArray;
}

/**
 *    @brief    从指定页面删除书签
 *
 *    @param     num     某个页面的第几个书签，总共是kMarkViewInOnePage个
 *    @param     beginIndex     删除的书签是所有书签的位置
 *    @param     page     在第几个页面删除书签
 *    @param     isPortrait     横竖屏标志
 */
- (void)deleteBookMarkViewWithNumber:(int)num BeginIndex:(int)beginIndex InOnePage:(int)page DeviceDirection:(BOOL)isPortrait {
    int numberCount = 0;
    for (int i=beginIndex+num -1; i>beginIndex-1; i--) {
        [(BookMarkView *)[_bookRemarkView viewWithTag:kBeginBookMarkViewTag + page*kMarkViewInOnePage + numberCount] removeFromSuperview];
        numberCount++;
        //删除_allMarkViewArray中的书签对象
        [_allMarkViewArray removeObjectAtIndex:i];
    }
}

/**
 *    @brief    当page变化时，刷新需要显示的BookMarkView
 *
 *    @param     isMoveNext     向左还是向右滑动
 *    @param     isPortrait     横竖屏标志
 */
- (void)reloadAllMarkViewForMoveDirection:(BOOL)isMoveNext DeviceDirection:(BOOL)isPortrait {
    int needReloadPage = 0;
    int numBookMarkViewInPage = 0;
    int beginDeleteIndex = 0;
    NSMutableArray *newBookMarkArray = nil;
    
    //移到_curPage + 1页
    if (isMoveNext) {
        //加载_curPage + 1页，不删除_curPage页
        if (_curPage==1) {
            needReloadPage = _curPage+1;
            numBookMarkViewInPage = ((_totalPage-1)>needReloadPage?kMarkViewInOnePage:([_allBookMarkArray count]-kMarkViewInOnePage*2));
            newBookMarkArray = [self addBookMarkViewWithNumber:numBookMarkViewInPage InOnePage:needReloadPage DeviceDirection:isPortrait];
            for (int i=0; i<[newBookMarkArray count]; i++) {
                [_allMarkViewArray addObject:[newBookMarkArray objectAtIndex:i]];
            }
        }
        else if(_curPage==_totalPage-1){
            //不加载_curPage + 1页，删除_curPage - 2页
            needReloadPage = _curPage-2;
            numBookMarkViewInPage = kMarkViewInOnePage;
            beginDeleteIndex = 0;
            [self deleteBookMarkViewWithNumber:numBookMarkViewInPage BeginIndex:beginDeleteIndex InOnePage:needReloadPage DeviceDirection:isPortrait];
        }
        else{
            //加载_curPage + 1页，删除_curPage - 2页
            //删除_curPage - 2页
            needReloadPage = _curPage - 2;
            numBookMarkViewInPage = kMarkViewInOnePage;
            beginDeleteIndex = 0;
            [self deleteBookMarkViewWithNumber:numBookMarkViewInPage BeginIndex:beginDeleteIndex InOnePage:needReloadPage DeviceDirection:isPortrait];
            
            //加载_curPage + 1页
            needReloadPage = _curPage + 1;
            if (needReloadPage == _totalPage - 1) {
                numBookMarkViewInPage = [_allBookMarkArray count] - needReloadPage *kMarkViewInOnePage;
            }else{
                numBookMarkViewInPage = kMarkViewInOnePage;
            }
            newBookMarkArray = [self addBookMarkViewWithNumber:numBookMarkViewInPage InOnePage:needReloadPage DeviceDirection:isPortrait];
            for (int i=0; i<[newBookMarkArray count]; i++) {
                [_allMarkViewArray addObject:[newBookMarkArray objectAtIndex:i]];
            }
        }
    }
    else{//移到_curPage - 1页
        if (_curPage==0) {//不加载_curPage - 1页，删除_curPage + 2页
            needReloadPage = 2;
            if (needReloadPage > _totalPage - 1) {
                return;
            }
            numBookMarkViewInPage = ((_totalPage-1)>needReloadPage?kMarkViewInOnePage:([_allBookMarkArray count]-kMarkViewInOnePage*2));
            beginDeleteIndex = kMarkViewInOnePage *2;
            [self deleteBookMarkViewWithNumber:numBookMarkViewInPage BeginIndex:beginDeleteIndex InOnePage:needReloadPage DeviceDirection:isPortrait];
        }
        else if(_curPage==_totalPage-2){//加载_curPage - 1页，不删除_curPage + 2页
            needReloadPage = _curPage - 1;
            numBookMarkViewInPage = kMarkViewInOnePage;
            newBookMarkArray = [self addBookMarkViewWithNumber:numBookMarkViewInPage InOnePage:needReloadPage DeviceDirection:isPortrait];
            NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:(NSArray *)_allMarkViewArray];
            [_allMarkViewArray removeAllObjects];
            for (int i = 0; i<([newBookMarkArray count]+[tempArray count]); i++) {
                if (i<12) [_allMarkViewArray addObject:[newBookMarkArray objectAtIndex:i]];
                else [_allMarkViewArray addObject:[tempArray objectAtIndex:i-12]];
            }
            
        }
        else{//加载_curPage - 1页，删除_curPage + 2页
            //删除_curPage + 2页
            needReloadPage = _curPage+2;
            if (needReloadPage < _totalPage) {
                if (needReloadPage == _totalPage - 1) {
                    numBookMarkViewInPage = [_allBookMarkArray count]-needReloadPage*kMarkViewInOnePage;
                }else{
                    numBookMarkViewInPage = kMarkViewInOnePage;
                }
                beginDeleteIndex = kMarkViewInOnePage *2;
                [self deleteBookMarkViewWithNumber:numBookMarkViewInPage BeginIndex:beginDeleteIndex InOnePage:needReloadPage DeviceDirection:isPortrait];
            }
            //加载_curPage - 1页
            needReloadPage = _curPage - 1;
            numBookMarkViewInPage = kMarkViewInOnePage;
            newBookMarkArray = [self addBookMarkViewWithNumber:numBookMarkViewInPage InOnePage:needReloadPage DeviceDirection:isPortrait];
            NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:(NSArray *)_allMarkViewArray];
            [_allMarkViewArray removeAllObjects];
            for (int i = 0; i<([newBookMarkArray count]+[tempArray count]); i++) {
                if (i<12) [_allMarkViewArray addObject:[newBookMarkArray objectAtIndex:i]];
                else [_allMarkViewArray addObject:[tempArray objectAtIndex:i-12]];
            }
            
        }
    }
    
}

/**
 *    @brief    删除书签后重先排列书签
 *
 *    @param     frame     书签页面在父页面中的位置
 *    @param     tag     书签tag
 *    @param     page     pagecontrol的页数
 *    @param     row     书签行数
 *    @param     component     书签列数
 *    @param     numResidualView     剩余的书签页数
 */
- (void)resetBookMarkViewFrameForDeletedViewFrame:(CGRect)frame
                                              Tag:(int)tag
                                             Page:(int)page
                                              Row:(int)row
                                        Component:(int)component
                                  NumResidualView:(int)numResidualView {
    if (numResidualView >= 0) {
        BookMarkView *bookMarkView = (BookMarkView *)[_bookRemarkView viewWithTag:tag];
        [self resetBookMarkViewFrameForDeletedViewFrame:bookMarkView.frame
                                                    Tag:++tag
                                                   Page:bookMarkView.page
                                                    Row:bookMarkView.row
                                              Component:bookMarkView.component
                                        NumResidualView:--numResidualView];
        [bookMarkView setPage:page];
        [bookMarkView setRow:row];
        [bookMarkView setComponent:component];
        [bookMarkView setTag:tag-2];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [bookMarkView setFrame:frame];
        [UIView commitAnimations];
        [bookMarkView setDelegate:self];
    }
}


#pragma mark -根据选择的书签，加载相应的资料，并显示书签对应的页码

- (void)loadPDFViewWithSelectedBookMark:(NSNumber *)pageNumber {
    
    HYRPDFReaderViewController *pDFReadViewController = [[HYRPDFReaderViewController alloc] init];
    pDFReadViewController.preViewIsSelectedBookMarkView = YES;
    pDFReadViewController.view.backgroundColor = [UIColor lightGrayColor];
    
    if (_isPushFromPDFReadView) {
        [self.navigationController popViewControllerAnimated:YES];
        //  显示pdf文档
        [pDFReadViewController showPDFWithFileMeta:_curMaterial andPage:[pageNumber intValue]];
        
        _isPushFromPDFReadView = NO;
        
    }else{
        [self.navigationController pushViewController:pDFReadViewController animated:YES];
        //  显示pdf文档
        [pDFReadViewController showPDFWithFileMeta:_curMaterial andPage:[pageNumber intValue]];
        
        //设置标志位 isPushFromBookMarkView
        [pDFReadViewController setIsPushFromBookMarkView:YES];
    }
    pDFReadViewController.preViewIsSelectedBookMarkView = NO;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -
#pragma mark =======    事件处理  =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


- (void)changePage:(id)sender {
    int page = _pageControl.currentPage;
    
    CGRect frame =_bookRemarkView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    [_bookRemarkView scrollRectToVisible:frame animated:YES];
    
    self.curPage = page;
    
    _pageControlUsed = YES;
}



#pragma mark =======    代理实现     =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -------- BookMarkViewDelegate ---删除批注-------

-(void)resetAllBookMarkView:(BookMarkView *)bookMarkView Frame:(CGRect)frame Tag:(NSInteger)tag Page:(NSInteger)page Row:(NSInteger)row Component:(NSInteger)component{
    __weak BookMarkView * weekBookMark = bookMarkView;
    __block NSInteger tempTag = tag;
    //弹出警告框
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reminder", nil) message:NSLocalizedString(@"Are you sure delete the comment?", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"cancel", nil) style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"sure", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //确认删除
        BOOL isPortrait = NO;
        int beginIndex = 0;
        int residualMarkViewNum = 0;//除去后页以前的书签还剩余多少书签
        int beginResetViewIndex = 0;//记录已删除bookMarkView的下一bookMarkView
        if (page == 0)
        {//当前页是首页
            beginIndex = 0;
            residualMarkViewNum = [_allBookMarkArray count] - 2*kMarkViewInOnePage;
        }
        else if(page == _totalPage-1)
        {//当前页是尾页
            beginIndex = kMarkViewInOnePage;
        }
        else
        {//当前页为中间页码
            beginIndex = kMarkViewInOnePage;
            residualMarkViewNum = [_allBookMarkArray count] - (page+2) *kMarkViewInOnePage;
        }
        
        //横竖屏
        if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
            isPortrait = YES;
            [_allMarkViewArray removeObjectAtIndex:beginIndex + (row - 1) *kPortraitComponent + component - 1];
            //删除对应的书签
            [_allBookMarkArray removeObjectAtIndex:page*kMarkViewInOnePage + (row - 1) *kPortraitComponent + component - 1];
            beginResetViewIndex = beginIndex +(row-1)*kPortraitComponent + component - 1 ;
        }else{
            isPortrait = NO;
            [_allMarkViewArray removeObjectAtIndex:beginIndex + (row - 1) *kLandscapeComponent + component - 1];
            //删除对应的书签
            [_allBookMarkArray removeObjectAtIndex:page*kMarkViewInOnePage + (row - 1) *kLandscapeComponent + component - 1];
            beginResetViewIndex = beginIndex + (row-1)*kLandscapeComponent + component - 1;
        }
        
        //如果最后一页的书签删除完，则自动跳到前一页
        int totalPage = (int)ceil([_allBookMarkArray count]/(kMarkViewInOnePage*1.0));
        if (_totalPage > totalPage && totalPage>0) {
            [_pageControl setNumberOfPages:totalPage];
            _totalPage = totalPage;
            if (isPortrait) {
                [_bookRemarkView setContentSize:CGSizeMake(_totalPage *BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                                           BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
                [_bookRemarkView setContentOffset:CGPointMake((_curPage)*BOOKMARKVIEW_SCROLLVIEW_WIDTH, 0.0) animated:YES];
            }else{
                [_bookRemarkView setContentSize:CGSizeMake(_totalPage *BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                                           BOOKMARKVIEW_SCROLLVIEW_HEIGHT)];
                [_bookRemarkView setContentOffset:CGPointMake((_curPage)*BOOKMARKVIEW_SCROLLVIEW_WIDTH, 0.0) animated:YES];
            }
            if (_curPage==_totalPage) {
                //如果当前页是最后一页
                self.curPage = page - 1;
            }
        }
        
        //添加BookMarkView到数组最后一个
        if (residualMarkViewNum > 0) {
            CGRect bookMarkViewFrame = CGRectZero;
            if (isPortrait) {
                bookMarkViewFrame = CGRectMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                               BOOKMARKVIEW_SCROLLVIEW_HEIGHT,
                                               155.0,
                                               205.0);
            }else{
                bookMarkViewFrame = CGRectMake(BOOKMARKVIEW_SCROLLVIEW_WIDTH,
                                               BOOKMARKVIEW_SCROLLVIEW_HEIGHT,
                                               155.0,
                                               205.0);
            }
            BookMarkView *bookMarkView = [[BookMarkView alloc] initWithFrame:bookMarkViewFrame];
            [bookMarkView setTag:kBeginBookMarkViewTag + (_curPage+2)*kMarkViewInOnePage];
            [bookMarkView setDelegate:self];
            [_bookRemarkView addSubview:bookMarkView];
            [_allMarkViewArray  addObject:bookMarkView];
            
        }
        int numResidualView = [_allMarkViewArray count] - beginResetViewIndex - 1;
         [self resetBookMarkViewFrameForDeletedViewFrame:frame Tag:++tempTag Page:page Row:row Component:component NumResidualView:numResidualView];
        //真的从父视图删除
        [weekBookMark removeFromSuperview];
        
    }];
    
    [alertVC addAction:cancelAction];
    [alertVC addAction:sureAction];
    [self presentViewController:alertVC animated:YES completion:nil];
}



#pragma mark - 保存批注数据到本地
- (void)saveHandDataToLocalWithCommentArr:(NSArray *) commentArr{
   
        NSString *remarkPath = nil;
        //判断文件类型
        if ([_curMaterial isKindOfClass:[HYRFileMeta class]]) {
            
            HYRFileMeta *fileMate = (HYRFileMeta *)_curMaterial;
            
            if (0 == commentArr.count) {
                fileMate.remarkPath = @"123";
            }else{
                fileMate.remarkPath = fileMate.materialid;
            }
            
            remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:fileMate.materialid];
//            [DataBaseManager saveData:commentArr toFile:remarkPath];
//            //更新数据库
//            [[DataBaseManager dataBaseManager] updateFromDatabaseWithFileMeta:fileMate];
            
        }
    
//        else if ([_curMaterial isKindOfClass:[NoticeAttachmentMate class]]) {
//            //通知文件
//            NoticeAttachmentMate *noticMate = (NoticeAttachmentMate *)_curMaterial;
//
//            if (0 == commentArr.count) {
//                noticMate.remarkPath = @"123";
//            }else{
//                noticMate.remarkPath = noticMate.materialid;
//            }
//
//            remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:noticMate.materialid];
//            [DataBaseManager saveData:commentArr toFile:remarkPath];
//            //更新数据库
//            [[DataBaseManager dataBaseManager] updateFromDatabaseWithFileMeta:noticMate];
//
//        }else if ([_curMaterial isKindOfClass:[GenericFileMeta class]]) {
//            //日常文件
//            GenericFileMeta *genericMate = (GenericFileMeta *)_curMaterial;
//
//            if (0 == commentArr.count) {
//                genericMate.remarkPath = @"123";
//            }else{
//                genericMate.remarkPath = genericMate.materialid;
//            }
//
//            remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:genericMate.materialid];
//            [DataBaseManager saveData:commentArr toFile:remarkPath];
//            //更新数据库
//            [[DataBaseManager dataBaseManager] updateFromDatabaseWithFileMeta:genericMate];
//
//        }else if ([_curMaterial isKindOfClass:[HistoryFileMeta class]]) {
//            //历史文件
//            HistoryFileMeta *historyMate = (HistoryFileMeta *)_curMaterial;
//
//            if (0 == commentArr.count) {
//                historyMate.remarkPath = @"123";
//            }else{
//                historyMate.remarkPath = historyMate.materialid;
//            }
//
//            remarkPath = [AgendaFileDirPath stringByAppendingPathComponent:historyMate.materialid];
//            [DataBaseManager saveData:commentArr toFile:remarkPath];
//            //更新数据库
//            [[DataBaseManager dataBaseManager] updateFromDatabaseWithFileMeta:historyMate];
//
//        }
    
}





/**
 *    @brief    显示指定页码的pdf页面
 *
 *    @param     pDFPage     pdf页码
 */

#pragma mark - 点击某一个标注的书签后 跳转到指定页码的pdf页面
- (void)showDataContentForPDFPage:(NSInteger)pDFPage {
    [SVProgressHUD showWithStatus:@"正在加载文件\n请稍后..."];
    [SVProgressHUD dismissWithDelay:2.0];
    
    [self performSelector:@selector(loadPDFViewWithSelectedBookMark:) withObject:[NSNumber numberWithInt:pDFPage] afterDelay:0.1];
}

/**
 *    @brief    显示或隐藏书签删除按钮
 *
 *    @param     isShow     是否显示删除按钮
 */
- (void)showBookMarkDeleteButton:(BOOL)isShow {
    _isDeleteModel = isShow;
}

#pragma mark ------- UIScrollViewDelegate ------------

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    if (_pageControlUsed) {
        return;
    }
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageWidth =_bookRemarkView.frame.size.width;
    int page = floor((_bookRemarkView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    //page可能小于零
    if (page < 0 || page > (_totalPage - 1)) return;
    _pageControl.currentPage = page;
    if (_curPage != page) {
        self.curPage = page;
    }
}

// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    _pageControlUsed = NO;
}



#pragma mark --------程序扩展     --------
- (void)relayoutForInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation withDuration:(NSTimeInterval)duration{
    
    _pageControlUsed = YES;//切换横竖屏时，会走scrollViewDidScroll方法（走完当前方法后才走）
    if (UIInterfaceOrientationIsPortrait(interfaceOrientation)){
        [self relayoutElementsForPortrait];
    }else{
        [self relayoutElementsForLandscape];
    }
    
}

#pragma mark --------系统自带  --------

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (void)loadView{
    [super loadView];
    UIView *selfView = [[UIView alloc] init];
    [self setView:selfView];
    
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    //
    [self loadContentView];
    [self loadPageControl];
//    [self addNavgationButton];
    if (_isMemoryWarning) {
        //[self showBookMarkWithAgendas:_agendas dataSource:_dataSourceArray index:_dataIndex];
        _isMemoryWarning = NO;
    }
    
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    int oldPage = [[change valueForKey:NSKeyValueChangeOldKey] intValue];
    int newPage = [[change valueForKey:NSKeyValueChangeNewKey] intValue];
    BOOL isPortrait = UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]);
    BOOL isMoveNext = (newPage > oldPage);
    [self reloadAllMarkViewForMoveDirection:isMoveNext DeviceDirection:isPortrait];
}

- (void)viewDidUnload{
    [super viewDidUnload];
    if (_contentView)
        _contentView = nil;
    if (_bookRemarkView)
        _bookRemarkView = nil;
    if (_pageControl)
        _pageControl = nil;
    
    _isMemoryWarning = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [self addObserver:self forKeyPath:@"curPage" options:NSKeyValueObservingOptionOld|NSKeyValueObservingOptionNew context:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self removeObserver:self forKeyPath:@"curPage"];
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    [self relayoutForInterfaceOrientation:toInterfaceOrientation withDuration:duration];
}

//
- (BOOL)shouldAutorotate{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskPortraitUpsideDown;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return [[UIApplication sharedApplication] statusBarOrientation];
}


@end
