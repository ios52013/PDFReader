//
//  BookMarkViewController.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookMarkView.h"
//#import "AgendaViewController.h"

//内容显示页面tableview得frame，相对内容显示页面
#define BOOKMARKVIEW_NAVIGATIONBAR_HEIGHT            80.0
#define BOOKMARKVIEW_SCROLLVIEW_X                    60.0
#define BOOKMARKVIEW_SCROLLVIEW_Y                    40.0
#define BOOKMARKVIEW_SCROLLVIEW_WIDTH       (kScreenWidth - BOOKMARKVIEW_SCROLLVIEW_X * 2)
#define BOOKMARKVIEW_SCROLLVIEW_HEIGHT      (kScreenHeight - BOOKMARKVIEW_NAVIGATIONBAR_HEIGHT- BOOKMARKVIEW_SCROLLVIEW_Y * 2)

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

//分页控制器
#define BOOKMARKVIEW_PAGECONTROL_WIDTH       kScreenWidth
#define BOOKMARKVIEW_PAGECONTROL_HEIGHT      20
#define BOOKMARKVIEW_PAGECONTROL_X           0
#define BOOKMARKVIEW_PAGECONTROL_Y           kScreenHeight - 80-(BOOKMARKVIEW_PAGECONTROL_HEIGHT * 2)

#define CONTENTVIEW_PORTRAIT_X                      0
#define CONTENTVIEW_Y                               80.0
#define CONTENTVIEW_PORTRAIT_WIDTH                  742.0
#define CONTENTVIEW_PORTRAIT_HEIGHT                 912.0


//#define BOOKMARKVIEW_PAGECONTROL_X                     11.0
//#define BOOKMARKVIEW_PAGECONTROL_PORTRAIT_Y                 876.0
//#define BOOKMARKVIEW_PAGECONTROL_LANDSCAPE_Y              606.0
//#define BOOKMARKVIEW_PAGECONTROL_PORTRAIT_WIDTH       715.0
//#define BOOKMARKVIEW_PAGECONTROL_LANDSCAPE_WIDTH     951.0
//#define BOOKMARKVIEW_PAGECONTROL_HEIGHT                          20.0


//标注页面的大小
#define BOOKMARKVIEW_SPACE      40.0
#define BOOKMARKVIEW_WIDTH      155.0
#define BOOKMARKVIEW_HEIGHT     205.0


/**
 *    @brief    批注书签界面控制器类，提供显示书签批注界面，进入前一界面入口
 */
@interface BookMarkViewController : UIViewController <UIScrollViewDelegate,BookMarkViewDelegate> {
    UIView *_contentView;                                        //内容显示界面
    UIImageView *_contentViewBackgroundView;       //背景页面
    UIScrollView *_bookRemarkView;                         //书签显示页面
    UIPageControl *_pageControl;                              //pageControl控件
    NSInteger _curPage;                                           //当前是第几页
    NSInteger _totalPage;                                         //记录共有多少页书签
    NSMutableArray *_allMarkViewArray;                 //当前需要的标签显示对象
    /**
     *  所有的标签对象
     */
    NSMutableArray *_allBookMarkArray;
    NSArray *_agendas;                                            //某个会议的所有会议议程
    NSArray *_dataSourceArray;                              //若前一个界面是会议资料界面，则数组保存所有的资料信息
    NSInteger _dataIndex;                                       //若前一个界面是会议资料界面，记录当前是第几份资料
    BOOL _pageControlUsed;                                      //标记scrollview滑动是否是pageControl改变引起的
    BOOL _isDeleteModel;                                         //书签界面是不是删除模式
    BOOL _preViewIsConferenceDataView;                //当前界面的前一个界面是不是会议资料界面
    /**
     *  判断当前页面的前一个页面是不是pdf阅读页面
     */
    BOOL _isPushFromPDFReadView;
    BOOL _isMemoryWarning;                                    //判断是否有内存警告
}

/**
 *    @brief    标示当前页码
 */
@property(nonatomic,assign)NSInteger curPage;

/**
 *    @brief    若前一个界面是会议资料界面，此属性记录当前是第几份资料
 */
@property(nonatomic,assign)NSInteger dataIndex;

/**
 *    @brief    判断当前页面的前一个页面是不是pdf阅读页面
 */
@property(nonatomic,assign)BOOL isPushFromPDFReadView;


/**
 显示指定会议资料的批注
 
 @param meta 指定会议资料
 */
- (void)showBookMarkWithFileMeta:(id)meta;
/**
 *    @brief    横竖屏切换时重先布局界面元素
 *
 *    @param     interfaceOrientation     当前屏幕方向
 *    @param     duration     横竖屏切换的动画时间
 */
- (void)relayoutForInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation withDuration:(NSTimeInterval)duration;

@end

