//
//  BookMarkView.h
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import <UIKit/UIKit.h>

@class BookMarkView;
/**
 *    @brief    BookMarkViewDelegate协议，提供重设书签位置，进入指定pdf阅读界面以及显示或隐藏书签删除按钮的功能
 */
@protocol BookMarkViewDelegate <NSObject>


//点击删除按钮回调
- (void)resetAllBookMarkView:(BookMarkView *)bookMarkView
                             Frame:(CGRect)frame
                              Tag:(NSInteger)tag
                             Page:(NSInteger)page
                              Row:(NSInteger)row
                        Component:(NSInteger)component;



/**
 *    @brief    显示指定页码的pdf页面
 *
 *    @param     pDFPage     pdf页码
 */
- (void)showDataContentForPDFPage:(NSInteger)pDFPage;

/**
 *    @brief    显示或隐藏书签删除按钮
 *
 *    @param     isShow     是否显示删除按钮
 */
- (void)showBookMarkDeleteButton:(BOOL)isShow;

@end

/**
 *    @brief    书签缩略图界面类，提供显示书签批注页缩略图，根据用户选择缩略图进入pdf阅读界面的入口
 */
@interface BookMarkView : UIView {
    /**
     *  书签在pagecontrol的页数
     */
    NSInteger _page;
    NSInteger _row;                                                //书签行数
    NSInteger _component;                                      //书签列数
    /**
     *  pdf文件的页数
     */
    NSInteger _pDFPage;
    NSInteger _chapter;                                          //pdf文件的章节
    UIImageView *_bookMarkBackgroundImageView;      //页面的缩略图
    NSTimeInterval  preTimestamp;                          //触摸开始时的时间
    id<BookMarkViewDelegate>delegate;                     //书签类的代理
}

/**
 *    @brief    书签在pagecontrol的页数
 */
@property(nonatomic)NSInteger page;

/**
 *    @brief    书签行数
 */
@property(nonatomic)NSInteger row;

/**
 *    @brief    书签列数
 */
@property(nonatomic)NSInteger component;

/**
 *    @brief    pdf文件的页数
 */
@property(nonatomic)NSInteger pDFPage;

/**
 *    @brief    pdf文件的章节
 */
@property(nonatomic)NSInteger chapter;

/**
 *    @brief    BookMarkViewDelegate代理
 */
@property(nonatomic,assign)id<BookMarkViewDelegate>delegate;

/**
 *    @brief    设置书签的背景图片
 *
 *    @param     backgroundImage     书签的背景图片
 */
- (void)setBookMarkViewBackImage:(UIImage *)backgroundImage;

/**
 *    @brief    控制删除按钮的显示状态
 *
 *    @param     isHidden     是否隐藏删除捥
 */
- (void)setDeleteButttonHidden:(BOOL)isHidden;

@end
