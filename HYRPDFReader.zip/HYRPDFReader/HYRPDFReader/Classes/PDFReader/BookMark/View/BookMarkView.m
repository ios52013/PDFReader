//
//  BookMarkView.m
//  PACM_ipad
//
//  Created by 黄永锐(EX-HUANGYONGRUI001) on 2018/2/2.
//  Copyright © 2018年 钟文成(外包). All rights reserved.
//

#import "BookMarkView.h"

static NSInteger kDeleteBtnTag = 99;

@interface BookMarkView ()

/**
 *    @brief    添加背景页面
 */
- (void)addBackgroundImageView;

/**
 *    @brief    添加删除按钮
 */
- (void)addDeleteBtn;

/**
 *    @brief    添加批注背景
 */
- (void)addBookMarkImageView;

/**
 *    @brief    删除按钮事件响应方法
 *
 *    @param     sender     删除按钮
 */
- (void)deleteBtnClick:(id)sender;

@end



@implementation BookMarkView
#pragma mark --------系统自带  --------

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addBackgroundImageView];
        [self addBookMarkImageView];
        [self addDeleteBtn];
    }
    return self;
}


/**
 *    @brief    添加背景页面
 */
- (void)addBackgroundImageView {
    UIImageView *backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
    [backgroundImageView  setImage:[UIImage imageNamed:@"icon_bookmark_bg"]];
    [self addSubview:backgroundImageView];
    
}

/**
 *    @brief    添加删除按钮
 */
- (void)addDeleteBtn {
    UIButton *deleteBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.0, 0.0, 30.0, 31.0)];
    [deleteBtn setTag:kDeleteBtnTag];
    [deleteBtn setBackgroundImage:[UIImage imageNamed:@"Com_ delete"] forState:UIControlStateNormal];
    [deleteBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:deleteBtn];
    [deleteBtn setHidden:YES];
   
}

/**
 *    @brief    添加批注背景
 */
- (void)addBookMarkImageView {
    _bookMarkBackgroundImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10.0, 10.0, self.frame.size.width - 20.0, self.frame.size.height - 20.0)];
    [_bookMarkBackgroundImageView setUserInteractionEnabled:YES];
    [self addSubview:_bookMarkBackgroundImageView];
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -
#pragma mark =======    逻辑处理     =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark ----     公有接口  ----
/**
 *    @brief    设置书签的背景图片
 *
 *    @param     backgroundImage     书签的背景图片
 */
- (void)setBookMarkViewBackImage:(UIImage *)backgroundImage {
    [_bookMarkBackgroundImageView setImage:backgroundImage];
}

/**
 *    @brief    控制删除按钮的显示状态
 *
 *    @param     isHidden     是否隐藏删除捥
 */
- (void)setDeleteButttonHidden:(BOOL)isHidden {
    [(UIButton *)[self viewWithTag:kDeleteBtnTag] setHidden:isHidden];
}

#pragma mark ----     私有接口      ----
//code here...


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -
#pragma mark =======    事件处理  =======
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
/**
 *    @brief    删除按钮事件响应方法
 *
 *    @param     sender     删除按钮
 */
- (void)deleteBtnClick:(id)sender {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(resetAllBookMarkView:Frame:Tag:Page:Row:Component:)]) {
        [self.delegate resetAllBookMarkView:self Frame:self.frame Tag:self.tag Page:self.page Row:self.row Component:self.component];
        //[self removeFromSuperview];
    }
    
}


//触摸事件
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    //获取开始触摸的时间
    preTimestamp = [[NSProcessInfo processInfo] systemUptime];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    if (([[NSProcessInfo processInfo] systemUptime] - preTimestamp) < 0.5) {
        UITouch *theTouch = [touches anyObject];
        if (theTouch.tapCount == 1) {
            //单击进入书签所在的页面
            if (self.delegate && [self.delegate respondsToSelector:@selector(showDataContentForPDFPage:)]) {
                [self.delegate showDataContentForPDFPage:self.pDFPage];
            }
        }
        else if(theTouch.tapCount == 2){
            //双击隐藏删除按钮
            if (self.delegate && [self.delegate respondsToSelector:@selector(showBookMarkDeleteButton:)]) {
                [self.delegate showBookMarkDeleteButton:NO];
            }
        }
    }
    else{
        //长按显示删除按钮
        if (self.delegate && [self.delegate respondsToSelector:@selector(showBookMarkDeleteButton:)]) {
            [self.delegate showBookMarkDeleteButton:YES];
        }
    }
}


@end
